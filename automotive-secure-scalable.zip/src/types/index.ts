// Core Types for Car Dealership SaaS

export type UserRole = 'super_admin' | 'dealership_owner' | 'sales_manager' | 'sales_agent' | 'accountant' | 'auditor';

export interface Role {
  id: string;
  name: UserRole;
  permissions: Record<string, string>;
  created_at: string;
}

export interface Dealership {
  id: string;
  name: string;
  license_number?: string;
  address?: string;
  city?: string;
  state?: string;
  zip_code?: string;
  phone?: string;
  email?: string;
  website?: string;
  logo_url?: string;
  primary_color: string;
  secondary_color: string;
  tax_id?: string;
  subscription_status: 'trial' | 'active' | 'past_due' | 'canceled' | 'expired';
  subscription_plan: 'starter' | 'professional' | 'enterprise';
  subscription_ends_at?: string;
  stripe_customer_id?: string;
  stripe_subscription_id?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface User {
  id: string;
  email: string;
  first_name?: string;
  last_name?: string;
  phone?: string;
  avatar_url?: string;
  role_id?: string;
  role?: Role;
  dealership_id?: string;
  dealership?: Dealership;
  is_active: boolean;
  email_verified: boolean;
  two_factor_enabled: boolean;
  last_login_at?: string;
  created_at: string;
  updated_at: string;
}

export interface Vehicle {
  id: string;
  dealership_id: string;
  vin?: string;
  stock_number?: string;
  year: number;
  make: string;
  model: string;
  trim?: string;
  body_type?: string;
  exterior_color?: string;
  interior_color?: string;
  mileage: number;
  engine?: string;
  transmission?: string;
  drivetrain?: string;
  fuel_type?: string;
  purchase_price?: number;
  listing_price?: number;
  msrp?: number;
  condition: 'new' | 'used' | 'certified';
  status: 'available' | 'pending' | 'sold' | 'reserved';
  description?: string;
  features: string[];
  images: string[];
  purchase_date?: string;
  sold_date?: string;
  created_by?: string;
  created_at: string;
  updated_at: string;
}

export interface Customer {
  id: string;
  dealership_id: string;
  first_name: string;
  last_name: string;
  email?: string;
  phone?: string;
  address?: string;
  city?: string;
  state?: string;
  zip_code?: string;
  date_of_birth?: string;
  drivers_license_number?: string;
  drivers_license_state?: string;
  drivers_license_expiry?: string;
  credit_score?: number;
  notes?: string;
  source?: string;
  status: 'active' | 'inactive';
  created_by?: string;
  created_at: string;
  updated_at: string;
}

export type DealStatus = 'lead' | 'quote' | 'negotiation' | 'paperwork' | 'financing' | 'closed' | 'lost';

export interface Deal {
  id: string;
  dealership_id: string;
  deal_number?: string;
  customer_id: string;
  customer?: Customer;
  vehicle_id: string;
  vehicle?: Vehicle;
  sales_agent_id?: string;
  sales_agent?: User;
  status: DealStatus;
  deal_type: 'retail' | 'wholesale' | 'lease';
  vehicle_price: number;
  trade_in_vehicle_id?: string;
  trade_in_value: number;
  trade_in_payoff: number;
  down_payment: number;
  tax_rate: number;
  tax_amount: number;
  doc_fee: number;
  title_fee: number;
  registration_fee: number;
  other_fees: number;
  total_fees: number;
  subtotal: number;
  total_price: number;
  amount_financed: number;
  apr: number;
  term_months: number;
  monthly_payment: number;
  lender_name?: string;
  financing_status?: string;
  notes?: string;
  closed_at?: string;
  created_by?: string;
  created_at: string;
  updated_at: string;
}

export type DocumentType = 
  | 'bill_of_sale'
  | 'buyers_order'
  | 'retail_installment_contract'
  | 'odometer_disclosure'
  | 'power_of_attorney'
  | 'as_is_warranty'
  | 'trade_in_agreement'
  | 'dealer_invoice'
  | 'receipt';

export interface Document {
  id: string;
  dealership_id: string;
  deal_id?: string;
  customer_id?: string;
  document_type: DocumentType;
  title: string;
  version: number;
  status: 'draft' | 'pending_signature' | 'signed' | 'voided';
  file_url?: string;
  file_hash?: string;
  content_data: Record<string, unknown>;
  state_jurisdiction?: string;
  requires_signature: boolean;
  signed_at?: string;
  signed_by_customer: boolean;
  signed_by_dealer: boolean;
  created_by?: string;
  created_at: string;
  updated_at: string;
}

export interface Signature {
  id: string;
  document_id: string;
  signer_type: 'customer' | 'dealer' | 'witness';
  signer_name: string;
  signer_email?: string;
  signature_data?: string;
  ip_address?: string;
  user_agent?: string;
  signed_at: string;
  certificate_hash?: string;
  created_at: string;
}

export interface Payment {
  id: string;
  dealership_id: string;
  deal_id?: string;
  payment_type: 'down_payment' | 'monthly' | 'payoff' | 'refund';
  amount: number;
  payment_method?: string;
  reference_number?: string;
  stripe_payment_id?: string;
  status: 'pending' | 'completed' | 'failed' | 'refunded';
  paid_at?: string;
  notes?: string;
  created_by?: string;
  created_at: string;
  updated_at: string;
}

export interface AuditLog {
  id: string;
  dealership_id?: string;
  user_id?: string;
  action: string;
  entity_type?: string;
  entity_id?: string;
  old_values?: Record<string, unknown>;
  new_values?: Record<string, unknown>;
  ip_address?: string;
  user_agent?: string;
  created_at: string;
}

export interface Subscription {
  id: string;
  dealership_id: string;
  plan_name: string;
  plan_price: number;
  billing_cycle: 'monthly' | 'yearly';
  status: 'active' | 'past_due' | 'canceled' | 'trialing';
  stripe_subscription_id?: string;
  stripe_price_id?: string;
  current_period_start?: string;
  current_period_end?: string;
  trial_ends_at?: string;
  canceled_at?: string;
  created_at: string;
  updated_at: string;
}

// Dashboard Stats
export interface DashboardStats {
  totalVehicles: number;
  availableVehicles: number;
  pendingDeals: number;
  closedDealsThisMonth: number;
  revenueThisMonth: number;
  totalCustomers: number;
  activeDeals: number;
}

// Subscription Plans
export interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  yearlyPrice: number;
  features: string[];
  maxVehicles: number;
  maxUsers: number;
  documentsIncluded: boolean;
  apiAccess: boolean;
  prioritySupport: boolean;
}
