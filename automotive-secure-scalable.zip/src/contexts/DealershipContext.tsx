import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '@/lib/supabase';
import { User, Dealership, Vehicle, Customer, Deal, Document, DashboardStats, UserRole } from '@/types';

interface DealershipContextType {
  // Auth state
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  isAuthenticated: boolean;
  
  // Dealership state
  currentDealership: Dealership | null;
  setCurrentDealership: (dealership: Dealership | null) => void;
  dealerships: Dealership[];
  
  // Data
  vehicles: Vehicle[];
  customers: Customer[];
  deals: Deal[];
  documents: Document[];
  stats: DashboardStats;
  
  // Loading states
  loading: boolean;
  
  // Actions
  refreshData: () => Promise<void>;
  addVehicle: (vehicle: Partial<Vehicle>) => Promise<Vehicle | null>;
  updateVehicle: (id: string, updates: Partial<Vehicle>) => Promise<void>;
  deleteVehicle: (id: string) => Promise<void>;
  addCustomer: (customer: Partial<Customer>) => Promise<Customer | null>;
  updateCustomer: (id: string, updates: Partial<Customer>) => Promise<void>;
  addDeal: (deal: Partial<Deal>) => Promise<Deal | null>;
  updateDeal: (id: string, updates: Partial<Deal>) => Promise<void>;
  
  // Navigation
  activeView: string;
  setActiveView: (view: string) => void;
}

const DealershipContext = createContext<DealershipContextType | undefined>(undefined);

export const useDealership = () => {
  const context = useContext(DealershipContext);
  if (!context) {
    throw new Error('useDealership must be used within a DealershipProvider');
  }
  return context;
};

interface DealershipProviderProps {
  children: ReactNode;
}

export const DealershipProvider: React.FC<DealershipProviderProps> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentRole, setCurrentRole] = useState<UserRole>('dealership_owner');
  const [currentDealership, setCurrentDealership] = useState<Dealership | null>(null);
  const [dealerships, setDealerships] = useState<Dealership[]>([]);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [deals, setDeals] = useState<Deal[]>([]);
  const [documents, setDocuments] = useState<Document[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeView, setActiveView] = useState('dashboard');
  
  const [stats, setStats] = useState<DashboardStats>({
    totalVehicles: 0,
    availableVehicles: 0,
    pendingDeals: 0,
    closedDealsThisMonth: 0,
    revenueThisMonth: 0,
    totalCustomers: 0,
    activeDeals: 0,
  });

  const isAuthenticated = currentUser !== null;

  // Initialize demo data
  useEffect(() => {
    initializeDemoData();
  }, []);

  const initializeDemoData = async () => {
    setLoading(true);
    try {
      // Check if demo dealership exists
      const { data: existingDealerships } = await supabase
        .from('dealerships')
        .select('*')
        .limit(1);

      if (!existingDealerships || existingDealerships.length === 0) {
        // Create demo dealership
        const { data: newDealership, error: dealershipError } = await supabase
          .from('dealerships')
          .insert({
            name: 'Premier Auto Sales',
            license_number: 'DLR-2024-001',
            address: '1234 Auto Drive',
            city: 'Los Angeles',
            state: 'CA',
            zip_code: '90001',
            phone: '(555) 123-4567',
            email: 'contact@premierautosales.com',
            website: 'https://premierautosales.com',
            primary_color: '#1e40af',
            secondary_color: '#10b981',
            tax_id: '12-3456789',
            subscription_status: 'active',
            subscription_plan: 'professional',
            is_active: true,
          })
          .select()
          .single();

        if (newDealership) {
          setCurrentDealership(newDealership);
          setDealerships([newDealership]);
          
          // Create demo vehicles
          await createDemoVehicles(newDealership.id);
          // Create demo customers
          await createDemoCustomers(newDealership.id);
        }
      } else {
        setCurrentDealership(existingDealerships[0]);
        setDealerships(existingDealerships);
      }

      // Set demo user
      setCurrentUser({
        id: 'demo-user-1',
        email: 'admin@premierautosales.com',
        first_name: 'John',
        last_name: 'Smith',
        is_active: true,
        email_verified: true,
        two_factor_enabled: false,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });

      await refreshData();
    } catch (error) {
      console.error('Error initializing demo data:', error);
    } finally {
      setLoading(false);
    }
  };

  const createDemoVehicles = async (dealershipId: string) => {
    const demoVehicles = [
      { year: 2024, make: 'BMW', model: 'X5', trim: 'xDrive40i', body_type: 'SUV', exterior_color: 'Alpine White', interior_color: 'Black', mileage: 1250, listing_price: 68995, status: 'available', condition: 'new', vin: '5UXCR6C55R9K12345', stock_number: 'STK001' },
      { year: 2023, make: 'Mercedes-Benz', model: 'E-Class', trim: 'E 350', body_type: 'Sedan', exterior_color: 'Obsidian Black', interior_color: 'Macchiato Beige', mileage: 8500, listing_price: 58995, status: 'available', condition: 'certified', vin: 'W1KZF8DB5PA12345', stock_number: 'STK002' },
      { year: 2024, make: 'Audi', model: 'Q7', trim: 'Premium Plus', body_type: 'SUV', exterior_color: 'Glacier White', interior_color: 'Black', mileage: 500, listing_price: 72500, status: 'pending', condition: 'new', vin: 'WA1VAAF77RD12345', stock_number: 'STK003' },
      { year: 2022, make: 'Porsche', model: 'Cayenne', trim: 'Base', body_type: 'SUV', exterior_color: 'Jet Black', interior_color: 'Black', mileage: 22000, listing_price: 74995, status: 'available', condition: 'used', vin: 'WP1AA2AY5NDA12345', stock_number: 'STK004' },
      { year: 2023, make: 'Tesla', model: 'Model S', trim: 'Plaid', body_type: 'Sedan', exterior_color: 'Pearl White', interior_color: 'White', mileage: 5200, listing_price: 89995, status: 'available', condition: 'used', vin: '5YJSA1E69PF12345', stock_number: 'STK005' },
      { year: 2024, make: 'Lexus', model: 'RX', trim: '350 F Sport', body_type: 'SUV', exterior_color: 'Caviar', interior_color: 'Circuit Red', mileage: 850, listing_price: 56995, status: 'available', condition: 'new', vin: '2T2HZMDA1RC12345', stock_number: 'STK006' },
      { year: 2023, make: 'Range Rover', model: 'Sport', trim: 'Dynamic SE', body_type: 'SUV', exterior_color: 'Santorini Black', interior_color: 'Ebony', mileage: 12500, listing_price: 92500, status: 'available', condition: 'certified', vin: 'SALWR2RU5PA12345', stock_number: 'STK007' },
      { year: 2022, make: 'Genesis', model: 'G80', trim: '3.5T Sport', body_type: 'Sedan', exterior_color: 'Vik Black', interior_color: 'Ultramarine Blue', mileage: 18000, listing_price: 48995, status: 'sold', condition: 'used', vin: 'KMTG34LA8NU12345', stock_number: 'STK008' },
      { year: 2024, make: 'Volvo', model: 'XC90', trim: 'Recharge', body_type: 'SUV', exterior_color: 'Crystal White', interior_color: 'Charcoal', mileage: 200, listing_price: 78500, status: 'available', condition: 'new', vin: 'YV4H60CZ5R1234567', stock_number: 'STK009' },
      { year: 2023, make: 'Jaguar', model: 'F-PACE', trim: 'R-Dynamic S', body_type: 'SUV', exterior_color: 'Firenze Red', interior_color: 'Ebony', mileage: 9800, listing_price: 62995, status: 'available', condition: 'certified', vin: 'SADCK2FX5PA12345', stock_number: 'STK010' },
      { year: 2024, make: 'Maserati', model: 'Grecale', trim: 'GT', body_type: 'SUV', exterior_color: 'Bianco', interior_color: 'Nero', mileage: 1500, listing_price: 79995, status: 'pending', condition: 'new', vin: 'ZN661YUA5RX12345', stock_number: 'STK011' },
      { year: 2022, make: 'Infiniti', model: 'QX60', trim: 'Luxe', body_type: 'SUV', exterior_color: 'Moonstone White', interior_color: 'Graphite', mileage: 28000, listing_price: 42995, status: 'available', condition: 'used', vin: '5N1DL1ES5NC12345', stock_number: 'STK012' },
    ];

    for (const vehicle of demoVehicles) {
      await supabase.from('vehicles').insert({
        dealership_id: dealershipId,
        ...vehicle,
        features: ['Leather Seats', 'Navigation', 'Backup Camera', 'Bluetooth', 'Heated Seats'],
        images: [],
      });
    }
  };

  const createDemoCustomers = async (dealershipId: string) => {
    const demoCustomers = [
      { first_name: 'Michael', last_name: 'Johnson', email: 'michael.j@email.com', phone: '(555) 234-5678', city: 'Los Angeles', state: 'CA', status: 'active', source: 'Website' },
      { first_name: 'Sarah', last_name: 'Williams', email: 'sarah.w@email.com', phone: '(555) 345-6789', city: 'Beverly Hills', state: 'CA', status: 'active', source: 'Referral' },
      { first_name: 'David', last_name: 'Brown', email: 'david.b@email.com', phone: '(555) 456-7890', city: 'Santa Monica', state: 'CA', status: 'active', source: 'Walk-in' },
      { first_name: 'Emily', last_name: 'Davis', email: 'emily.d@email.com', phone: '(555) 567-8901', city: 'Pasadena', state: 'CA', status: 'active', source: 'Website' },
      { first_name: 'James', last_name: 'Wilson', email: 'james.w@email.com', phone: '(555) 678-9012', city: 'Glendale', state: 'CA', status: 'active', source: 'Social Media' },
      { first_name: 'Jennifer', last_name: 'Martinez', email: 'jennifer.m@email.com', phone: '(555) 789-0123', city: 'Burbank', state: 'CA', status: 'active', source: 'Referral' },
    ];

    for (const customer of demoCustomers) {
      await supabase.from('customers').insert({
        dealership_id: dealershipId,
        ...customer,
      });
    }
  };

  const refreshData = async () => {
    if (!currentDealership?.id) return;

    try {
      // Fetch vehicles
      const { data: vehiclesData } = await supabase
        .from('vehicles')
        .select('*')
        .eq('dealership_id', currentDealership.id)
        .is('deleted_at', null)
        .order('created_at', { ascending: false });

      if (vehiclesData) {
        setVehicles(vehiclesData);
      }

      // Fetch customers
      const { data: customersData } = await supabase
        .from('customers')
        .select('*')
        .eq('dealership_id', currentDealership.id)
        .is('deleted_at', null)
        .order('created_at', { ascending: false });

      if (customersData) {
        setCustomers(customersData);
      }

      // Fetch deals
      const { data: dealsData } = await supabase
        .from('deals')
        .select('*')
        .eq('dealership_id', currentDealership.id)
        .is('deleted_at', null)
        .order('created_at', { ascending: false });

      if (dealsData) {
        setDeals(dealsData);
      }

      // Fetch documents
      const { data: documentsData } = await supabase
        .from('documents')
        .select('*')
        .eq('dealership_id', currentDealership.id)
        .is('deleted_at', null)
        .order('created_at', { ascending: false });

      if (documentsData) {
        setDocuments(documentsData);
      }

      // Calculate stats
      const availableVehicles = vehiclesData?.filter(v => v.status === 'available').length || 0;
      const pendingDeals = dealsData?.filter(d => ['lead', 'quote', 'negotiation', 'paperwork', 'financing'].includes(d.status)).length || 0;
      const closedDeals = dealsData?.filter(d => d.status === 'closed') || [];
      const thisMonth = new Date();
      thisMonth.setDate(1);
      const closedThisMonth = closedDeals.filter(d => new Date(d.closed_at || d.created_at) >= thisMonth);
      const revenueThisMonth = closedThisMonth.reduce((sum, d) => sum + (d.total_price || 0), 0);

      setStats({
        totalVehicles: vehiclesData?.length || 0,
        availableVehicles,
        pendingDeals,
        closedDealsThisMonth: closedThisMonth.length,
        revenueThisMonth,
        totalCustomers: customersData?.length || 0,
        activeDeals: pendingDeals,
      });
    } catch (error) {
      console.error('Error refreshing data:', error);
    }
  };

  useEffect(() => {
    if (currentDealership?.id) {
      refreshData();
    }
  }, [currentDealership?.id]);

  const addVehicle = async (vehicle: Partial<Vehicle>): Promise<Vehicle | null> => {
    if (!currentDealership?.id) return null;

    const { data, error } = await supabase
      .from('vehicles')
      .insert({
        ...vehicle,
        dealership_id: currentDealership.id,
      })
      .select()
      .single();

    if (error) {
      console.error('Error adding vehicle:', error);
      return null;
    }

    await refreshData();
    return data;
  };

  const updateVehicle = async (id: string, updates: Partial<Vehicle>) => {
    const { error } = await supabase
      .from('vehicles')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id);

    if (error) {
      console.error('Error updating vehicle:', error);
      return;
    }

    await refreshData();
  };

  const deleteVehicle = async (id: string) => {
    const { error } = await supabase
      .from('vehicles')
      .update({ deleted_at: new Date().toISOString() })
      .eq('id', id);

    if (error) {
      console.error('Error deleting vehicle:', error);
      return;
    }

    await refreshData();
  };

  const addCustomer = async (customer: Partial<Customer>): Promise<Customer | null> => {
    if (!currentDealership?.id) return null;

    const { data, error } = await supabase
      .from('customers')
      .insert({
        ...customer,
        dealership_id: currentDealership.id,
      })
      .select()
      .single();

    if (error) {
      console.error('Error adding customer:', error);
      return null;
    }

    await refreshData();
    return data;
  };

  const updateCustomer = async (id: string, updates: Partial<Customer>) => {
    const { error } = await supabase
      .from('customers')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id);

    if (error) {
      console.error('Error updating customer:', error);
      return;
    }

    await refreshData();
  };

  const addDeal = async (deal: Partial<Deal>): Promise<Deal | null> => {
    if (!currentDealership?.id) return null;

    const dealNumber = `DL-${Date.now().toString().slice(-8)}`;
    
    const { data, error } = await supabase
      .from('deals')
      .insert({
        ...deal,
        dealership_id: currentDealership.id,
        deal_number: dealNumber,
      })
      .select()
      .single();

    if (error) {
      console.error('Error adding deal:', error);
      return null;
    }

    await refreshData();
    return data;
  };

  const updateDeal = async (id: string, updates: Partial<Deal>) => {
    const { error } = await supabase
      .from('deals')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id);

    if (error) {
      console.error('Error updating deal:', error);
      return;
    }

    await refreshData();
  };

  return (
    <DealershipContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        currentRole,
        setCurrentRole,
        isAuthenticated,
        currentDealership,
        setCurrentDealership,
        dealerships,
        vehicles,
        customers,
        deals,
        documents,
        stats,
        loading,
        refreshData,
        addVehicle,
        updateVehicle,
        deleteVehicle,
        addCustomer,
        updateCustomer,
        addDeal,
        updateDeal,
        activeView,
        setActiveView,
      }}
    >
      {children}
    </DealershipContext.Provider>
  );
};
