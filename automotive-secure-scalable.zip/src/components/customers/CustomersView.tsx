import React, { useState, useMemo } from 'react';
import { useDealership } from '@/contexts/DealershipContext';
import { Customer } from '@/types';
import { 
  Users, 
  Plus, 
  Search, 
  MoreVertical,
  Edit,
  Trash2,
  Eye,
  X,
  Phone,
  Mail,
  MapPin,
  Calendar,
  FileText,
  Handshake
} from 'lucide-react';

const CustomersView: React.FC = () => {
  const { customers, addCustomer, updateCustomer } = useDealership();
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [showDropdown, setShowDropdown] = useState<string | null>(null);

  const [newCustomer, setNewCustomer] = useState({
    first_name: '',
    last_name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zip_code: '',
    date_of_birth: '',
    drivers_license_number: '',
    drivers_license_state: '',
    source: '',
    notes: '',
  });

  const filteredCustomers = useMemo(() => {
    return customers.filter(customer => {
      const fullName = `${customer.first_name} ${customer.last_name}`.toLowerCase();
      const searchLower = searchQuery.toLowerCase();
      return (
        fullName.includes(searchLower) ||
        customer.email?.toLowerCase().includes(searchLower) ||
        customer.phone?.includes(searchQuery)
      );
    });
  }, [customers, searchQuery]);

  const handleAddCustomer = async () => {
    if (!newCustomer.first_name || !newCustomer.last_name) return;
    
    await addCustomer({
      ...newCustomer,
      status: 'active',
    });
    
    setShowAddModal(false);
    setNewCustomer({
      first_name: '',
      last_name: '',
      email: '',
      phone: '',
      address: '',
      city: '',
      state: '',
      zip_code: '',
      date_of_birth: '',
      drivers_license_number: '',
      drivers_license_state: '',
      source: '',
      notes: '',
    });
  };

  const getInitials = (firstName: string, lastName: string) => {
    return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();
  };

  const getSourceColor = (source?: string) => {
    const colors: Record<string, string> = {
      'Website': 'bg-blue-500/20 text-blue-400',
      'Referral': 'bg-emerald-500/20 text-emerald-400',
      'Walk-in': 'bg-amber-500/20 text-amber-400',
      'Social Media': 'bg-purple-500/20 text-purple-400',
      'Phone': 'bg-cyan-500/20 text-cyan-400',
    };
    return colors[source || ''] || 'bg-slate-500/20 text-slate-400';
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Customer Management</h1>
          <p className="text-slate-400">{filteredCustomers.length} customers in database</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Add Customer
        </button>
      </div>

      {/* Search */}
      <div className="bg-slate-800 rounded-xl border border-slate-700 p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search by name, email, or phone..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Customers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredCustomers.map((customer) => (
          <div
            key={customer.id}
            className="bg-slate-800 rounded-xl border border-slate-700 p-5 hover:border-slate-600 transition-all"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-emerald-500 rounded-full flex items-center justify-center text-white font-semibold">
                  {getInitials(customer.first_name, customer.last_name)}
                </div>
                <div>
                  <h3 className="font-semibold text-white">
                    {customer.first_name} {customer.last_name}
                  </h3>
                  {customer.source && (
                    <span className={`inline-flex px-2 py-0.5 rounded text-xs font-medium ${getSourceColor(customer.source)}`}>
                      {customer.source}
                    </span>
                  )}
                </div>
              </div>
              <div className="relative">
                <button
                  onClick={() => setShowDropdown(showDropdown === customer.id ? null : customer.id)}
                  className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-700 rounded transition-colors"
                >
                  <MoreVertical className="w-4 h-4" />
                </button>
                {showDropdown === customer.id && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setShowDropdown(null)} />
                    <div className="absolute right-0 top-full mt-1 w-40 bg-slate-800 border border-slate-700 rounded-lg shadow-xl z-50 py-1">
                      <button
                        onClick={() => {
                          setSelectedCustomer(customer);
                          setShowDetailModal(true);
                          setShowDropdown(null);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-slate-300 hover:bg-slate-700"
                      >
                        <Eye className="w-4 h-4" /> View Details
                      </button>
                      <button className="w-full flex items-center gap-2 px-3 py-2 text-slate-300 hover:bg-slate-700">
                        <Edit className="w-4 h-4" /> Edit
                      </button>
                      <button className="w-full flex items-center gap-2 px-3 py-2 text-slate-300 hover:bg-slate-700">
                        <Handshake className="w-4 h-4" /> Create Deal
                      </button>
                      <div className="border-t border-slate-700 my-1" />
                      <button className="w-full flex items-center gap-2 px-3 py-2 text-red-400 hover:bg-slate-700">
                        <Trash2 className="w-4 h-4" /> Delete
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>

            <div className="mt-4 space-y-2">
              {customer.email && (
                <div className="flex items-center gap-2 text-sm text-slate-400">
                  <Mail className="w-4 h-4" />
                  <span className="truncate">{customer.email}</span>
                </div>
              )}
              {customer.phone && (
                <div className="flex items-center gap-2 text-sm text-slate-400">
                  <Phone className="w-4 h-4" />
                  <span>{customer.phone}</span>
                </div>
              )}
              {customer.city && customer.state && (
                <div className="flex items-center gap-2 text-sm text-slate-400">
                  <MapPin className="w-4 h-4" />
                  <span>{customer.city}, {customer.state}</span>
                </div>
              )}
            </div>

            <div className="mt-4 pt-4 border-t border-slate-700 flex items-center justify-between">
              <button
                onClick={() => {
                  setSelectedCustomer(customer);
                  setShowDetailModal(true);
                }}
                className="text-sm text-blue-400 hover:text-blue-300"
              >
                View Profile
              </button>
              <span className="text-xs text-slate-500">
                Added {new Date(customer.created_at).toLocaleDateString()}
              </span>
            </div>
          </div>
        ))}
      </div>

      {filteredCustomers.length === 0 && (
        <div className="bg-slate-800 rounded-xl border border-slate-700 p-12 text-center">
          <Users className="w-16 h-16 text-slate-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-white mb-2">No customers found</h3>
          <p className="text-slate-400 mb-4">
            {searchQuery ? 'Try adjusting your search' : 'Add your first customer to get started'}
          </p>
          {!searchQuery && (
            <button
              onClick={() => setShowAddModal(true)}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors"
            >
              Add Customer
            </button>
          )}
        </div>
      )}

      {/* Add Customer Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setShowAddModal(false)} />
          <div className="relative bg-slate-800 rounded-xl border border-slate-700 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-slate-800 p-5 border-b border-slate-700 flex items-center justify-between">
              <h2 className="text-xl font-semibold text-white">Add New Customer</h2>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">First Name *</label>
                  <input
                    type="text"
                    value={newCustomer.first_name}
                    onChange={(e) => setNewCustomer({ ...newCustomer, first_name: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Last Name *</label>
                  <input
                    type="text"
                    value={newCustomer.last_name}
                    onChange={(e) => setNewCustomer({ ...newCustomer, last_name: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Email</label>
                  <input
                    type="email"
                    value={newCustomer.email}
                    onChange={(e) => setNewCustomer({ ...newCustomer, email: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Phone</label>
                  <input
                    type="tel"
                    value={newCustomer.phone}
                    onChange={(e) => setNewCustomer({ ...newCustomer, phone: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-slate-300 mb-1">Address</label>
                  <input
                    type="text"
                    value={newCustomer.address}
                    onChange={(e) => setNewCustomer({ ...newCustomer, address: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">City</label>
                  <input
                    type="text"
                    value={newCustomer.city}
                    onChange={(e) => setNewCustomer({ ...newCustomer, city: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">State</label>
                    <input
                      type="text"
                      value={newCustomer.state}
                      onChange={(e) => setNewCustomer({ ...newCustomer, state: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">ZIP</label>
                    <input
                      type="text"
                      value={newCustomer.zip_code}
                      onChange={(e) => setNewCustomer({ ...newCustomer, zip_code: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Date of Birth</label>
                  <input
                    type="date"
                    value={newCustomer.date_of_birth}
                    onChange={(e) => setNewCustomer({ ...newCustomer, date_of_birth: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Lead Source</label>
                  <select
                    value={newCustomer.source}
                    onChange={(e) => setNewCustomer({ ...newCustomer, source: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Select source</option>
                    <option value="Website">Website</option>
                    <option value="Referral">Referral</option>
                    <option value="Walk-in">Walk-in</option>
                    <option value="Social Media">Social Media</option>
                    <option value="Phone">Phone</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Driver's License #</label>
                  <input
                    type="text"
                    value={newCustomer.drivers_license_number}
                    onChange={(e) => setNewCustomer({ ...newCustomer, drivers_license_number: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">DL State</label>
                  <input
                    type="text"
                    value={newCustomer.drivers_license_state}
                    onChange={(e) => setNewCustomer({ ...newCustomer, drivers_license_state: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Notes</label>
                <textarea
                  value={newCustomer.notes}
                  onChange={(e) => setNewCustomer({ ...newCustomer, notes: e.target.value })}
                  rows={3}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div className="sticky bottom-0 bg-slate-800 p-5 border-t border-slate-700 flex justify-end gap-3">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleAddCustomer}
                disabled={!newCustomer.first_name || !newCustomer.last_name}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Add Customer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Customer Detail Modal */}
      {showDetailModal && selectedCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setShowDetailModal(false)} />
          <div className="relative bg-slate-800 rounded-xl border border-slate-700 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-slate-800 p-5 border-b border-slate-700 flex items-center justify-between">
              <h2 className="text-xl font-semibold text-white">Customer Profile</h2>
              <button
                onClick={() => setShowDetailModal(false)}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-5">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-emerald-500 rounded-full flex items-center justify-center text-white text-2xl font-semibold">
                  {getInitials(selectedCustomer.first_name, selectedCustomer.last_name)}
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white">
                    {selectedCustomer.first_name} {selectedCustomer.last_name}
                  </h3>
                  {selectedCustomer.source && (
                    <span className={`inline-flex px-2 py-0.5 rounded text-xs font-medium ${getSourceColor(selectedCustomer.source)}`}>
                      Lead: {selectedCustomer.source}
                    </span>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <p className="text-sm text-slate-400 flex items-center gap-2">
                    <Mail className="w-4 h-4" /> Email
                  </p>
                  <p className="text-white">{selectedCustomer.email || 'N/A'}</p>
                </div>
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <p className="text-sm text-slate-400 flex items-center gap-2">
                    <Phone className="w-4 h-4" /> Phone
                  </p>
                  <p className="text-white">{selectedCustomer.phone || 'N/A'}</p>
                </div>
                <div className="col-span-2 bg-slate-700/50 rounded-lg p-4">
                  <p className="text-sm text-slate-400 flex items-center gap-2">
                    <MapPin className="w-4 h-4" /> Address
                  </p>
                  <p className="text-white">
                    {selectedCustomer.address ? (
                      <>
                        {selectedCustomer.address}<br />
                        {selectedCustomer.city}, {selectedCustomer.state} {selectedCustomer.zip_code}
                      </>
                    ) : 'N/A'}
                  </p>
                </div>
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <p className="text-sm text-slate-400 flex items-center gap-2">
                    <Calendar className="w-4 h-4" /> Date of Birth
                  </p>
                  <p className="text-white">
                    {selectedCustomer.date_of_birth 
                      ? new Date(selectedCustomer.date_of_birth).toLocaleDateString() 
                      : 'N/A'}
                  </p>
                </div>
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <p className="text-sm text-slate-400 flex items-center gap-2">
                    <FileText className="w-4 h-4" /> Driver's License
                  </p>
                  <p className="text-white">
                    {selectedCustomer.drivers_license_number 
                      ? `${selectedCustomer.drivers_license_number} (${selectedCustomer.drivers_license_state})` 
                      : 'N/A'}
                  </p>
                </div>
              </div>

              {selectedCustomer.notes && (
                <div className="mt-4 bg-slate-700/50 rounded-lg p-4">
                  <p className="text-sm text-slate-400 mb-2">Notes</p>
                  <p className="text-white">{selectedCustomer.notes}</p>
                </div>
              )}
            </div>
            <div className="sticky bottom-0 bg-slate-800 p-5 border-t border-slate-700 flex justify-end gap-3">
              <button className="px-4 py-2 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg transition-colors">
                Edit Customer
              </button>
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors">
                Create Deal
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CustomersView;
