import React, { useState } from 'react';
import { DealershipProvider, useDealership } from '@/contexts/DealershipContext';
import Sidebar from '@/components/ui/Sidebar';
import Header from '@/components/ui/Header';
import DashboardView from '@/components/dashboard/DashboardView';
import InventoryView from '@/components/inventory/InventoryView';
import CustomersView from '@/components/customers/CustomersView';
import DealsView from '@/components/deals/DealsView';
import DocumentsView from '@/components/documents/DocumentsView';
import ReportsView from '@/components/reports/ReportsView';
import SubscriptionView from '@/components/subscription/SubscriptionView';
import SettingsView from '@/components/settings/SettingsView';
import AdminView from '@/components/admin/AdminView';
import PaymentsView from '@/components/payments/PaymentsView';
import { Loader2 } from 'lucide-react';

const MainContent: React.FC = () => {
  const { activeView, loading } = useDealership();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-blue-500 animate-spin mx-auto mb-4" />
          <p className="text-slate-400">Loading dealership data...</p>
        </div>
      </div>
    );
  }

  const renderView = () => {
    switch (activeView) {
      case 'dashboard':
        return <DashboardView />;
      case 'inventory':
        return <InventoryView />;
      case 'customers':
        return <CustomersView />;
      case 'deals':
        return <DealsView />;
      case 'documents':
        return <DocumentsView />;
      case 'payments':
        return <PaymentsView />;
      case 'reports':
        return <ReportsView />;
      case 'subscription':
        return <SubscriptionView />;
      case 'settings':
        return <SettingsView />;
      case 'admin':
      case 'dealerships':
        return <AdminView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-900">
      {/* Sidebar */}
      <Sidebar 
        collapsed={sidebarCollapsed} 
        onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} 
      />

      {/* Main Content Area */}
      <div className={`transition-all duration-300 ${sidebarCollapsed ? 'ml-20' : 'ml-64'}`}>
        {/* Header */}
        <Header onMenuToggle={() => setSidebarCollapsed(!sidebarCollapsed)} />

        {/* Page Content */}
        <main className="min-h-[calc(100vh-4rem)]">
          {renderView()}
        </main>
      </div>
    </div>
  );
};

const AppLayout: React.FC = () => {
  return (
    <DealershipProvider>
      <MainContent />
    </DealershipProvider>
  );
};

export default AppLayout;
