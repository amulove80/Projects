import React, { useState, useMemo } from 'react';
import { useDealership } from '@/contexts/DealershipContext';
import { DocumentType } from '@/types';
import { supabase } from '@/lib/supabase';
import { 
  FileText, 
  Plus, 
  Search, 
  Download,
  Eye,
  X,
  ChevronDown,
  PenTool,
  FileCheck,
  FileClock,
  FileX,
  Loader2
} from 'lucide-react';

const DocumentsView: React.FC = () => {
  const { documents, deals, customers, vehicles, currentDealership } = useDealership();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [showGenerateModal, setShowGenerateModal] = useState(false);
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [selectedDealId, setSelectedDealId] = useState('');
  const [selectedDocType, setSelectedDocType] = useState<DocumentType>('bill_of_sale');
  const [generatedDocument, setGeneratedDocument] = useState<{ title: string; content: string; hash: string } | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const documentTypes: { id: DocumentType; label: string; description: string }[] = [
    { id: 'bill_of_sale', label: 'Bill of Sale', description: 'Official document transferring vehicle ownership' },
    { id: 'buyers_order', label: "Buyer's Order", description: 'Itemized list of all charges and fees' },
    { id: 'retail_installment_contract', label: 'Retail Installment Contract', description: 'Financing agreement terms and conditions' },
    { id: 'odometer_disclosure', label: 'Odometer Disclosure', description: 'Federal odometer disclosure statement' },
    { id: 'power_of_attorney', label: 'Power of Attorney', description: 'Authorization for title/registration' },
    { id: 'as_is_warranty', label: 'As-Is / Warranty Disclosure', description: 'Vehicle warranty status disclosure' },
    { id: 'trade_in_agreement', label: 'Trade-In Agreement', description: 'Trade-in vehicle terms and valuation' },
    { id: 'dealer_invoice', label: 'Dealer Invoice', description: 'Internal dealer invoice document' },
    { id: 'receipt', label: 'Receipt', description: 'Payment receipt documentation' },
  ];

  const filteredDocuments = useMemo(() => {
    return documents.filter(doc => {
      const matchesSearch = doc.title.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === 'all' || doc.status === statusFilter;
      const matchesType = typeFilter === 'all' || doc.document_type === typeFilter;
      return matchesSearch && matchesStatus && matchesType;
    });
  }, [documents, searchQuery, statusFilter, typeFilter]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'draft': return <FileClock className="w-4 h-4 text-slate-400" />;
      case 'pending_signature': return <PenTool className="w-4 h-4 text-amber-400" />;
      case 'signed': return <FileCheck className="w-4 h-4 text-emerald-400" />;
      case 'voided': return <FileX className="w-4 h-4 text-red-400" />;
      default: return <FileText className="w-4 h-4 text-slate-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'draft': return 'bg-slate-500/20 text-slate-400';
      case 'pending_signature': return 'bg-amber-500/20 text-amber-400';
      case 'signed': return 'bg-emerald-500/20 text-emerald-400';
      case 'voided': return 'bg-red-500/20 text-red-400';
      default: return 'bg-slate-500/20 text-slate-400';
    }
  };

  const getDocumentTypeLabel = (type: DocumentType) => {
    return documentTypes.find(dt => dt.id === type)?.label || type;
  };

  const getDealInfo = (dealId?: string) => {
    if (!dealId) return null;
    const deal = deals.find(d => d.id === dealId);
    if (!deal) return null;
    const customer = customers.find(c => c.id === deal.customer_id);
    const vehicle = vehicles.find(v => v.id === deal.vehicle_id);
    return { deal, customer, vehicle };
  };

  const handleGenerateDocument = async () => {
    if (!selectedDealId || !currentDealership) return;
    
    setIsGenerating(true);
    
    try {
      const dealInfo = getDealInfo(selectedDealId);
      if (!dealInfo) throw new Error('Deal not found');

      const { deal, customer, vehicle } = dealInfo;

      const { data, error } = await supabase.functions.invoke('generate-document', {
        body: {
          document_type: selectedDocType,
          deal_id: selectedDealId,
          dealership_id: currentDealership.id,
          customer_data: {
            first_name: customer?.first_name || '',
            last_name: customer?.last_name || '',
            address: customer?.address || '',
            city: customer?.city || '',
            state: customer?.state || '',
            zip_code: customer?.zip_code || '',
            drivers_license_number: customer?.drivers_license_number || '',
            drivers_license_state: customer?.drivers_license_state || '',
          },
          vehicle_data: {
            year: vehicle?.year || 0,
            make: vehicle?.make || '',
            model: vehicle?.model || '',
            vin: vehicle?.vin || '',
            mileage: vehicle?.mileage || 0,
            exterior_color: vehicle?.exterior_color || '',
          },
          deal_data: {
            deal_number: deal.deal_number || '',
            vehicle_price: deal.vehicle_price || 0,
            trade_in_value: deal.trade_in_value || 0,
            down_payment: deal.down_payment || 0,
            tax_amount: deal.tax_amount || 0,
            total_fees: deal.total_fees || 0,
            total_price: deal.total_price || 0,
            amount_financed: deal.amount_financed || 0,
            apr: deal.apr || 0,
            term_months: deal.term_months || 0,
            monthly_payment: deal.monthly_payment || 0,
          },
          dealership_data: {
            name: currentDealership.name,
            address: currentDealership.address || '',
            city: currentDealership.city || '',
            state: currentDealership.state || '',
            zip_code: currentDealership.zip_code || '',
            phone: currentDealership.phone || '',
            license_number: currentDealership.license_number || '',
          },
        },
      });

      if (error) throw error;

      if (data?.success && data?.document) {
        setGeneratedDocument({
          title: data.document.title,
          content: data.document.content,
          hash: data.document.hash,
        });
        setShowGenerateModal(false);
        setShowPreviewModal(true);
      }
    } catch (error) {
      console.error('Error generating document:', error);
      alert('Failed to generate document. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Document Management</h1>
          <p className="text-slate-400">{filteredDocuments.length} documents</p>
        </div>
        <button
          onClick={() => setShowGenerateModal(true)}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Generate Document
        </button>
      </div>

      {/* Filters */}
      <div className="bg-slate-800 rounded-xl border border-slate-700 p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search documents..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="relative">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="appearance-none px-4 py-2 pr-10 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Status</option>
              <option value="draft">Draft</option>
              <option value="pending_signature">Pending Signature</option>
              <option value="signed">Signed</option>
              <option value="voided">Voided</option>
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
          </div>
          <div className="relative">
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="appearance-none px-4 py-2 pr-10 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Types</option>
              {documentTypes.map(type => (
                <option key={type.id} value={type.id}>{type.label}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Document Types Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {documentTypes.map((docType) => (
          <div
            key={docType.id}
            className="bg-slate-800 rounded-xl border border-slate-700 p-5 hover:border-slate-600 transition-all cursor-pointer"
            onClick={() => {
              setSelectedDocType(docType.id);
              setShowGenerateModal(true);
            }}
          >
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                <FileText className="w-6 h-6 text-blue-400" />
              </div>
              <div>
                <h3 className="font-semibold text-white">{docType.label}</h3>
                <p className="text-sm text-slate-400 mt-1">{docType.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Documents List */}
      <div className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden">
        <div className="p-5 border-b border-slate-700">
          <h2 className="text-lg font-semibold text-white">Recent Documents</h2>
        </div>
        {filteredDocuments.length > 0 ? (
          <div className="divide-y divide-slate-700">
            {filteredDocuments.map((doc) => {
              const dealInfo = getDealInfo(doc.deal_id);
              return (
                <div key={doc.id} className="p-4 hover:bg-slate-700/30 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-slate-700 rounded-lg flex items-center justify-center">
                        {getStatusIcon(doc.status)}
                      </div>
                      <div>
                        <h4 className="font-medium text-white">{doc.title}</h4>
                        <div className="flex items-center gap-3 mt-1">
                          <span className="text-sm text-slate-400">
                            {getDocumentTypeLabel(doc.document_type)}
                          </span>
                          {dealInfo && (
                            <span className="text-sm text-slate-500">
                              {dealInfo.customer?.first_name} {dealInfo.customer?.last_name}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className={`px-2 py-1 rounded text-xs font-medium ${getStatusColor(doc.status)}`}>
                        {doc.status.replace('_', ' ')}
                      </span>
                      <div className="flex items-center gap-1">
                        <button className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded transition-colors">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded transition-colors">
                          <Download className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-12 text-center">
            <FileText className="w-16 h-16 text-slate-600 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-white mb-2">No documents found</h3>
            <p className="text-slate-400 mb-4">Generate your first document to get started</p>
            <button
              onClick={() => setShowGenerateModal(true)}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors"
            >
              Generate Document
            </button>
          </div>
        )}
      </div>

      {/* Generate Document Modal */}
      {showGenerateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setShowGenerateModal(false)} />
          <div className="relative bg-slate-800 rounded-xl border border-slate-700 w-full max-w-lg">
            <div className="p-5 border-b border-slate-700 flex items-center justify-between">
              <h2 className="text-xl font-semibold text-white">Generate Document</h2>
              <button
                onClick={() => setShowGenerateModal(false)}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Document Type *</label>
                <select
                  value={selectedDocType}
                  onChange={(e) => setSelectedDocType(e.target.value as DocumentType)}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {documentTypes.map(type => (
                    <option key={type.id} value={type.id}>{type.label}</option>
                  ))}
                </select>
                <p className="text-sm text-slate-400 mt-1">
                  {documentTypes.find(t => t.id === selectedDocType)?.description}
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Select Deal *</label>
                <select
                  value={selectedDealId}
                  onChange={(e) => setSelectedDealId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select a deal</option>
                  {deals.map(deal => {
                    const customer = customers.find(c => c.id === deal.customer_id);
                    const vehicle = vehicles.find(v => v.id === deal.vehicle_id);
                    return (
                      <option key={deal.id} value={deal.id}>
                        {deal.deal_number} - {customer?.first_name} {customer?.last_name} ({vehicle?.year} {vehicle?.make} {vehicle?.model})
                      </option>
                    );
                  })}
                </select>
              </div>
              
              {selectedDealId && (
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <h4 className="font-medium text-white mb-2">Deal Summary</h4>
                  {(() => {
                    const dealInfo = getDealInfo(selectedDealId);
                    if (!dealInfo) return null;
                    return (
                      <div className="space-y-1 text-sm">
                        <p className="text-slate-300">
                          <span className="text-slate-400">Customer:</span> {dealInfo.customer?.first_name} {dealInfo.customer?.last_name}
                        </p>
                        <p className="text-slate-300">
                          <span className="text-slate-400">Vehicle:</span> {dealInfo.vehicle?.year} {dealInfo.vehicle?.make} {dealInfo.vehicle?.model}
                        </p>
                        <p className="text-slate-300">
                          <span className="text-slate-400">Total:</span> ${dealInfo.deal.total_price?.toLocaleString()}
                        </p>
                      </div>
                    );
                  })()}
                </div>
              )}
            </div>
            <div className="p-5 border-t border-slate-700 flex justify-end gap-3">
              <button
                onClick={() => setShowGenerateModal(false)}
                className="px-4 py-2 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleGenerateDocument}
                disabled={!selectedDealId || isGenerating}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <FileText className="w-4 h-4" />
                    Generate Document
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Document Preview Modal */}
      {showPreviewModal && generatedDocument && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setShowPreviewModal(false)} />
          <div className="relative bg-slate-800 rounded-xl border border-slate-700 w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
            <div className="p-5 border-b border-slate-700 flex items-center justify-between flex-shrink-0">
              <div>
                <h2 className="text-xl font-semibold text-white">{generatedDocument.title}</h2>
                <p className="text-sm text-slate-400 font-mono mt-1">Hash: {generatedDocument.hash.slice(0, 16)}...</p>
              </div>
              <button
                onClick={() => setShowPreviewModal(false)}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-5">
              <pre className="bg-white text-slate-900 p-6 rounded-lg font-mono text-sm whitespace-pre-wrap leading-relaxed">
                {generatedDocument.content}
              </pre>
            </div>
            <div className="p-5 border-t border-slate-700 flex justify-end gap-3 flex-shrink-0">
              <button
                onClick={() => setShowPreviewModal(false)}
                className="px-4 py-2 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
              >
                Close
              </button>
              <button className="px-4 py-2 bg-slate-700 text-white rounded-lg hover:bg-slate-600 transition-colors flex items-center gap-2">
                <PenTool className="w-4 h-4" />
                Request Signature
              </button>
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors flex items-center gap-2">
                <Download className="w-4 h-4" />
                Download PDF
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DocumentsView;
