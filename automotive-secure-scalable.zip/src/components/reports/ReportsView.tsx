import React, { useState, useMemo } from 'react';
import { useDealership } from '@/contexts/DealershipContext';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown,
  DollarSign,
  Car,
  Users,
  Handshake,
  Download,
  Calendar,
  ChevronDown,
  FileText,
  PieChart
} from 'lucide-react';

const ReportsView: React.FC = () => {
  const { vehicles, customers, deals, stats } = useDealership();
  const [dateRange, setDateRange] = useState('month');
  const [reportType, setReportType] = useState('overview');

  // Calculate metrics
  const metrics = useMemo(() => {
    const closedDeals = deals.filter(d => d.status === 'closed');
    const totalRevenue = closedDeals.reduce((sum, d) => sum + (d.total_price || 0), 0);
    const totalProfit = closedDeals.reduce((sum, d) => {
      const vehicle = vehicles.find(v => v.id === d.vehicle_id);
      const cost = vehicle?.purchase_price || 0;
      return sum + ((d.total_price || 0) - cost);
    }, 0);
    const avgDealValue = closedDeals.length > 0 ? totalRevenue / closedDeals.length : 0;
    
    const vehiclesByStatus = {
      available: vehicles.filter(v => v.status === 'available').length,
      pending: vehicles.filter(v => v.status === 'pending').length,
      sold: vehicles.filter(v => v.status === 'sold').length,
    };

    const dealsByStatus = {
      lead: deals.filter(d => d.status === 'lead').length,
      quote: deals.filter(d => d.status === 'quote').length,
      negotiation: deals.filter(d => d.status === 'negotiation').length,
      paperwork: deals.filter(d => d.status === 'paperwork').length,
      financing: deals.filter(d => d.status === 'financing').length,
      closed: deals.filter(d => d.status === 'closed').length,
    };

    return {
      totalRevenue,
      totalProfit,
      avgDealValue,
      closedDealsCount: closedDeals.length,
      vehiclesByStatus,
      dealsByStatus,
    };
  }, [vehicles, deals]);

  const summaryCards = [
    {
      title: 'Total Revenue',
      value: `$${metrics.totalRevenue.toLocaleString()}`,
      change: '+12.5%',
      changeType: 'positive',
      icon: DollarSign,
      color: 'from-emerald-500 to-emerald-600',
    },
    {
      title: 'Gross Profit',
      value: `$${metrics.totalProfit.toLocaleString()}`,
      change: '+8.2%',
      changeType: 'positive',
      icon: TrendingUp,
      color: 'from-blue-500 to-blue-600',
    },
    {
      title: 'Avg Deal Value',
      value: `$${metrics.avgDealValue.toLocaleString()}`,
      change: '+5.1%',
      changeType: 'positive',
      icon: BarChart3,
      color: 'from-purple-500 to-purple-600',
    },
    {
      title: 'Closed Deals',
      value: metrics.closedDealsCount.toString(),
      change: '-2.3%',
      changeType: 'negative',
      icon: Handshake,
      color: 'from-amber-500 to-amber-600',
    },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Reports & Analytics</h1>
          <p className="text-slate-400">Track your dealership performance</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="appearance-none px-4 py-2 pr-10 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="week">This Week</option>
              <option value="month">This Month</option>
              <option value="quarter">This Quarter</option>
              <option value="year">This Year</option>
            </select>
            <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
          </div>
          <button className="px-4 py-2 bg-slate-700 text-white rounded-lg hover:bg-slate-600 transition-colors flex items-center gap-2">
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryCards.map((card, index) => {
          const Icon = card.icon;
          return (
            <div
              key={index}
              className="bg-slate-800 rounded-xl border border-slate-700 p-5 hover:border-slate-600 transition-all"
            >
              <div className="flex items-center justify-between mb-3">
                <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${card.color} flex items-center justify-center`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <span className={`flex items-center text-xs font-medium ${
                  card.changeType === 'positive' ? 'text-emerald-400' : 'text-red-400'
                }`}>
                  {card.changeType === 'positive' ? (
                    <TrendingUp className="w-3 h-3 mr-0.5" />
                  ) : (
                    <TrendingDown className="w-3 h-3 mr-0.5" />
                  )}
                  {card.change}
                </span>
              </div>
              <p className="text-2xl font-bold text-white">{card.value}</p>
              <p className="text-sm text-slate-400 mt-1">{card.title}</p>
            </div>
          );
        })}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Inventory Status */}
        <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Car className="w-5 h-5" />
            Inventory Status
          </h3>
          <div className="space-y-4">
            {[
              { label: 'Available', value: metrics.vehiclesByStatus.available, color: 'bg-emerald-500', total: vehicles.length },
              { label: 'Pending', value: metrics.vehiclesByStatus.pending, color: 'bg-amber-500', total: vehicles.length },
              { label: 'Sold', value: metrics.vehiclesByStatus.sold, color: 'bg-blue-500', total: vehicles.length },
            ].map((item, index) => (
              <div key={index}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-slate-300">{item.label}</span>
                  <span className="text-white font-medium">{item.value}</span>
                </div>
                <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${item.color} rounded-full transition-all duration-500`}
                    style={{ width: `${item.total > 0 ? (item.value / item.total) * 100 : 0}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-4 border-t border-slate-700">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Total Inventory</span>
              <span className="text-xl font-bold text-white">{vehicles.length}</span>
            </div>
          </div>
        </div>

        {/* Deal Pipeline */}
        <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Handshake className="w-5 h-5" />
            Deal Pipeline
          </h3>
          <div className="space-y-4">
            {[
              { label: 'Lead', value: metrics.dealsByStatus.lead, color: 'bg-slate-500' },
              { label: 'Quote', value: metrics.dealsByStatus.quote, color: 'bg-cyan-500' },
              { label: 'Negotiation', value: metrics.dealsByStatus.negotiation, color: 'bg-amber-500' },
              { label: 'Paperwork', value: metrics.dealsByStatus.paperwork, color: 'bg-blue-500' },
              { label: 'Financing', value: metrics.dealsByStatus.financing, color: 'bg-purple-500' },
              { label: 'Closed', value: metrics.dealsByStatus.closed, color: 'bg-emerald-500' },
            ].map((item, index) => (
              <div key={index} className="flex items-center gap-3">
                <div className={`w-3 h-3 rounded-full ${item.color}`} />
                <span className="text-slate-300 flex-1">{item.label}</span>
                <span className="text-white font-medium">{item.value}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-4 border-t border-slate-700">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Total Active Deals</span>
              <span className="text-xl font-bold text-white">{deals.length}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Reports */}
      <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
        <h3 className="text-lg font-semibold text-white mb-4">Quick Reports</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { title: 'Daily Sales Report', description: 'Sales summary for today', icon: FileText },
            { title: 'Tax Report', description: 'Tax collected by state', icon: DollarSign },
            { title: 'Commission Report', description: 'Sales agent commissions', icon: Users },
            { title: 'Inventory Aging', description: 'Days on lot analysis', icon: Car },
          ].map((report, index) => {
            const Icon = report.icon;
            return (
              <button
                key={index}
                className="bg-slate-700/50 rounded-lg p-4 text-left hover:bg-slate-700 transition-colors group"
              >
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-8 h-8 bg-blue-500/20 rounded-lg flex items-center justify-center group-hover:bg-blue-500/30 transition-colors">
                    <Icon className="w-4 h-4 text-blue-400" />
                  </div>
                  <h4 className="font-medium text-white">{report.title}</h4>
                </div>
                <p className="text-sm text-slate-400">{report.description}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Top Performers */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Selling Vehicles */}
        <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
          <h3 className="text-lg font-semibold text-white mb-4">Top Selling Makes</h3>
          <div className="space-y-3">
            {['BMW', 'Mercedes-Benz', 'Audi', 'Porsche', 'Tesla'].map((make, index) => (
              <div key={make} className="flex items-center gap-3">
                <span className="w-6 h-6 bg-slate-700 rounded-full flex items-center justify-center text-xs font-medium text-slate-300">
                  {index + 1}
                </span>
                <span className="text-white flex-1">{make}</span>
                <span className="text-slate-400">{Math.floor(Math.random() * 10) + 1} sold</span>
              </div>
            ))}
          </div>
        </div>

        {/* Customer Sources */}
        <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
          <h3 className="text-lg font-semibold text-white mb-4">Customer Sources</h3>
          <div className="space-y-3">
            {[
              { source: 'Website', percentage: 35, color: 'bg-blue-500' },
              { source: 'Referral', percentage: 28, color: 'bg-emerald-500' },
              { source: 'Walk-in', percentage: 20, color: 'bg-amber-500' },
              { source: 'Social Media', percentage: 12, color: 'bg-purple-500' },
              { source: 'Phone', percentage: 5, color: 'bg-cyan-500' },
            ].map((item) => (
              <div key={item.source}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-slate-300">{item.source}</span>
                  <span className="text-white font-medium">{item.percentage}%</span>
                </div>
                <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${item.color} rounded-full transition-all duration-500`}
                    style={{ width: `${item.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReportsView;
