import React from 'react';
import { useDealership } from '@/contexts/DealershipContext';
import { 
  Car, 
  Users, 
  DollarSign, 
  TrendingUp, 
  Clock, 
  CheckCircle,
  AlertCircle,
  ArrowUpRight,
  ArrowDownRight,
  FileText,
  Handshake
} from 'lucide-react';

const DashboardView: React.FC = () => {
  const { stats, vehicles, customers, deals, currentDealership } = useDealership();

  const statCards = [
    {
      title: 'Total Inventory',
      value: stats.totalVehicles,
      change: '+12%',
      changeType: 'positive',
      icon: Car,
      color: 'from-blue-500 to-blue-600',
    },
    {
      title: 'Available Vehicles',
      value: stats.availableVehicles,
      change: '+5%',
      changeType: 'positive',
      icon: CheckCircle,
      color: 'from-emerald-500 to-emerald-600',
    },
    {
      title: 'Active Deals',
      value: stats.activeDeals,
      change: '+18%',
      changeType: 'positive',
      icon: Handshake,
      color: 'from-amber-500 to-amber-600',
    },
    {
      title: 'Monthly Revenue',
      value: `$${stats.revenueThisMonth.toLocaleString()}`,
      change: '+24%',
      changeType: 'positive',
      icon: DollarSign,
      color: 'from-purple-500 to-purple-600',
    },
    {
      title: 'Total Customers',
      value: stats.totalCustomers,
      change: '+8%',
      changeType: 'positive',
      icon: Users,
      color: 'from-cyan-500 to-cyan-600',
    },
    {
      title: 'Closed This Month',
      value: stats.closedDealsThisMonth,
      change: '-3%',
      changeType: 'negative',
      icon: TrendingUp,
      color: 'from-rose-500 to-rose-600',
    },
  ];

  const recentVehicles = vehicles.slice(0, 5);
  const recentDeals = deals.slice(0, 5);

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      available: 'bg-emerald-500/20 text-emerald-400',
      pending: 'bg-amber-500/20 text-amber-400',
      sold: 'bg-blue-500/20 text-blue-400',
      reserved: 'bg-purple-500/20 text-purple-400',
      lead: 'bg-slate-500/20 text-slate-400',
      quote: 'bg-cyan-500/20 text-cyan-400',
      negotiation: 'bg-amber-500/20 text-amber-400',
      paperwork: 'bg-blue-500/20 text-blue-400',
      financing: 'bg-purple-500/20 text-purple-400',
      closed: 'bg-emerald-500/20 text-emerald-400',
      lost: 'bg-red-500/20 text-red-400',
    };
    return colors[status] || 'bg-slate-500/20 text-slate-400';
  };

  return (
    <div className="p-6 space-y-6">
      {/* Welcome Section */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Welcome back!</h1>
          <p className="text-slate-400">Here's what's happening at {currentDealership?.name}</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="px-4 py-2 bg-slate-700 text-white rounded-lg hover:bg-slate-600 transition-colors flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Generate Report
          </button>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors flex items-center gap-2">
            <Car className="w-4 h-4" />
            Add Vehicle
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {statCards.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div
              key={index}
              className="bg-slate-800 rounded-xl p-5 border border-slate-700 hover:border-slate-600 transition-all hover:shadow-lg"
            >
              <div className="flex items-center justify-between mb-3">
                <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <span className={`flex items-center text-xs font-medium ${
                  stat.changeType === 'positive' ? 'text-emerald-400' : 'text-red-400'
                }`}>
                  {stat.changeType === 'positive' ? (
                    <ArrowUpRight className="w-3 h-3 mr-0.5" />
                  ) : (
                    <ArrowDownRight className="w-3 h-3 mr-0.5" />
                  )}
                  {stat.change}
                </span>
              </div>
              <p className="text-2xl font-bold text-white">{stat.value}</p>
              <p className="text-sm text-slate-400 mt-1">{stat.title}</p>
            </div>
          );
        })}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Inventory */}
        <div className="bg-slate-800 rounded-xl border border-slate-700">
          <div className="p-5 border-b border-slate-700 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-white">Recent Inventory</h2>
            <button className="text-sm text-blue-400 hover:text-blue-300">View All</button>
          </div>
          <div className="divide-y divide-slate-700">
            {recentVehicles.map((vehicle) => (
              <div key={vehicle.id} className="p-4 hover:bg-slate-700/50 transition-colors">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-12 bg-slate-700 rounded-lg flex items-center justify-center">
                    <Car className="w-6 h-6 text-slate-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-white truncate">
                      {vehicle.year} {vehicle.make} {vehicle.model}
                    </p>
                    <p className="text-sm text-slate-400">
                      {vehicle.stock_number} • {vehicle.mileage.toLocaleString()} mi
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-white">
                      ${vehicle.listing_price?.toLocaleString()}
                    </p>
                    <span className={`inline-flex px-2 py-0.5 rounded text-xs font-medium ${getStatusColor(vehicle.status)}`}>
                      {vehicle.status}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Deals */}
        <div className="bg-slate-800 rounded-xl border border-slate-700">
          <div className="p-5 border-b border-slate-700 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-white">Recent Deals</h2>
            <button className="text-sm text-blue-400 hover:text-blue-300">View All</button>
          </div>
          <div className="divide-y divide-slate-700">
            {recentDeals.length > 0 ? (
              recentDeals.map((deal) => (
                <div key={deal.id} className="p-4 hover:bg-slate-700/50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-white">{deal.deal_number}</p>
                      <p className="text-sm text-slate-400">
                        ${deal.total_price?.toLocaleString() || '0'}
                      </p>
                    </div>
                    <span className={`inline-flex px-2 py-0.5 rounded text-xs font-medium ${getStatusColor(deal.status)}`}>
                      {deal.status}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-8 text-center">
                <Handshake className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                <p className="text-slate-400">No deals yet</p>
                <button className="mt-3 text-sm text-blue-400 hover:text-blue-300">
                  Create your first deal
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
        <h2 className="text-lg font-semibold text-white mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {[
            { label: 'Add Vehicle', icon: Car, color: 'bg-blue-600 hover:bg-blue-500' },
            { label: 'New Customer', icon: Users, color: 'bg-emerald-600 hover:bg-emerald-500' },
            { label: 'Create Deal', icon: Handshake, color: 'bg-amber-600 hover:bg-amber-500' },
            { label: 'Generate Doc', icon: FileText, color: 'bg-purple-600 hover:bg-purple-500' },
            { label: 'Record Payment', icon: DollarSign, color: 'bg-cyan-600 hover:bg-cyan-500' },
            { label: 'View Reports', icon: TrendingUp, color: 'bg-rose-600 hover:bg-rose-500' },
          ].map((action, index) => {
            const Icon = action.icon;
            return (
              <button
                key={index}
                className={`${action.color} text-white rounded-lg p-4 flex flex-col items-center gap-2 transition-colors`}
              >
                <Icon className="w-6 h-6" />
                <span className="text-sm font-medium">{action.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Activity Timeline */}
      <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
        <h2 className="text-lg font-semibold text-white mb-4">Recent Activity</h2>
        <div className="space-y-4">
          {[
            { action: 'Vehicle added to inventory', detail: '2024 BMW X5 xDrive40i', time: '10 minutes ago', icon: Car, color: 'bg-blue-500' },
            { action: 'Customer profile created', detail: 'Michael Johnson', time: '1 hour ago', icon: Users, color: 'bg-emerald-500' },
            { action: 'Deal status updated', detail: 'DL-12345678 moved to Paperwork', time: '2 hours ago', icon: Handshake, color: 'bg-amber-500' },
            { action: 'Document generated', detail: 'Bill of Sale for Deal #DL-12345678', time: '3 hours ago', icon: FileText, color: 'bg-purple-500' },
            { action: 'Payment received', detail: '$5,000 down payment', time: '4 hours ago', icon: DollarSign, color: 'bg-cyan-500' },
          ].map((activity, index) => {
            const Icon = activity.icon;
            return (
              <div key={index} className="flex items-start gap-4">
                <div className={`w-8 h-8 ${activity.color} rounded-full flex items-center justify-center flex-shrink-0`}>
                  <Icon className="w-4 h-4 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white font-medium">{activity.action}</p>
                  <p className="text-sm text-slate-400">{activity.detail}</p>
                </div>
                <p className="text-xs text-slate-500 flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {activity.time}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default DashboardView;
