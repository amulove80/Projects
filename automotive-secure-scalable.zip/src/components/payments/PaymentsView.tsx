import React, { useState } from 'react';
import { useDealership } from '@/contexts/DealershipContext';
import { 
  DollarSign, 
  Plus, 
  Search, 
  Download,
  CheckCircle,
  Clock,
  AlertCircle,
  XCircle,
  CreditCard,
  Banknote,
  Building2,
  ChevronDown,
  X
} from 'lucide-react';

const PaymentsView: React.FC = () => {
  const { deals, customers, vehicles } = useDealership();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showRecordModal, setShowRecordModal] = useState(false);

  const [newPayment, setNewPayment] = useState({
    deal_id: '',
    payment_type: 'down_payment',
    amount: 0,
    payment_method: 'card',
    reference_number: '',
    notes: '',
  });

  // Mock payments data
  const payments = [
    { id: 1, deal_number: 'DL-12345678', customer: 'Michael Johnson', amount: 5000, type: 'down_payment', method: 'card', status: 'completed', date: '2026-01-10' },
    { id: 2, deal_number: 'DL-12345679', customer: 'Sarah Williams', amount: 3500, type: 'down_payment', method: 'check', status: 'completed', date: '2026-01-09' },
    { id: 3, deal_number: 'DL-12345680', customer: 'David Brown', amount: 750, type: 'monthly', method: 'ach', status: 'pending', date: '2026-01-08' },
    { id: 4, deal_number: 'DL-12345681', customer: 'Emily Davis', amount: 2000, type: 'down_payment', method: 'cash', status: 'completed', date: '2026-01-07' },
    { id: 5, deal_number: 'DL-12345682', customer: 'James Wilson', amount: 850, type: 'monthly', method: 'card', status: 'failed', date: '2026-01-06' },
  ];

  const filteredPayments = payments.filter(payment => {
    const matchesSearch = 
      payment.deal_number.toLowerCase().includes(searchQuery.toLowerCase()) ||
      payment.customer.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || payment.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-4 h-4 text-emerald-400" />;
      case 'pending': return <Clock className="w-4 h-4 text-amber-400" />;
      case 'failed': return <XCircle className="w-4 h-4 text-red-400" />;
      default: return <AlertCircle className="w-4 h-4 text-slate-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-emerald-500/20 text-emerald-400';
      case 'pending': return 'bg-amber-500/20 text-amber-400';
      case 'failed': return 'bg-red-500/20 text-red-400';
      default: return 'bg-slate-500/20 text-slate-400';
    }
  };

  const getMethodIcon = (method: string) => {
    switch (method) {
      case 'card': return <CreditCard className="w-4 h-4" />;
      case 'cash': return <Banknote className="w-4 h-4" />;
      case 'check': return <Building2 className="w-4 h-4" />;
      case 'ach': return <Building2 className="w-4 h-4" />;
      default: return <DollarSign className="w-4 h-4" />;
    }
  };

  const totalReceived = payments
    .filter(p => p.status === 'completed')
    .reduce((sum, p) => sum + p.amount, 0);

  const totalPending = payments
    .filter(p => p.status === 'pending')
    .reduce((sum, p) => sum + p.amount, 0);

  const handleRecordPayment = () => {
    alert('Payment recorded successfully! (Demo)');
    setShowRecordModal(false);
    setNewPayment({
      deal_id: '',
      payment_type: 'down_payment',
      amount: 0,
      payment_method: 'card',
      reference_number: '',
      notes: '',
    });
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Payment Management</h1>
          <p className="text-slate-400">Track and manage all payments</p>
        </div>
        <button
          onClick={() => setShowRecordModal(true)}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Record Payment
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-emerald-500/20 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-emerald-400" />
            </div>
            <span className="text-slate-400">Received</span>
          </div>
          <p className="text-2xl font-bold text-white">${totalReceived.toLocaleString()}</p>
        </div>
        <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-amber-500/20 rounded-lg flex items-center justify-center">
              <Clock className="w-5 h-5 text-amber-400" />
            </div>
            <span className="text-slate-400">Pending</span>
          </div>
          <p className="text-2xl font-bold text-white">${totalPending.toLocaleString()}</p>
        </div>
        <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-blue-400" />
            </div>
            <span className="text-slate-400">This Month</span>
          </div>
          <p className="text-2xl font-bold text-white">$12,100</p>
        </div>
        <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
              <CreditCard className="w-5 h-5 text-purple-400" />
            </div>
            <span className="text-slate-400">Transactions</span>
          </div>
          <p className="text-2xl font-bold text-white">{payments.length}</p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-slate-800 rounded-xl border border-slate-700 p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search by deal number or customer..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="relative">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="appearance-none px-4 py-2 pr-10 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Status</option>
              <option value="completed">Completed</option>
              <option value="pending">Pending</option>
              <option value="failed">Failed</option>
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
          </div>
          <button className="px-4 py-2 bg-slate-700 text-white rounded-lg hover:bg-slate-600 transition-colors flex items-center gap-2">
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>
      </div>

      {/* Payments Table */}
      <div className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-700/50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase">Deal</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase">Customer</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase">Type</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase">Method</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase">Amount</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase">Status</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase">Date</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-700">
            {filteredPayments.map((payment) => (
              <tr key={payment.id} className="hover:bg-slate-700/30 transition-colors">
                <td className="px-4 py-4 font-mono text-white">{payment.deal_number}</td>
                <td className="px-4 py-4 text-white">{payment.customer}</td>
                <td className="px-4 py-4 text-slate-300 capitalize">{payment.type.replace('_', ' ')}</td>
                <td className="px-4 py-4">
                  <div className="flex items-center gap-2 text-slate-300">
                    {getMethodIcon(payment.method)}
                    <span className="capitalize">{payment.method}</span>
                  </div>
                </td>
                <td className="px-4 py-4 text-white font-semibold">${payment.amount.toLocaleString()}</td>
                <td className="px-4 py-4">
                  <span className={`inline-flex items-center gap-1.5 px-2 py-1 rounded text-xs font-medium ${getStatusColor(payment.status)}`}>
                    {getStatusIcon(payment.status)}
                    {payment.status}
                  </span>
                </td>
                <td className="px-4 py-4 text-slate-400">{new Date(payment.date).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredPayments.length === 0 && (
          <div className="p-12 text-center">
            <DollarSign className="w-16 h-16 text-slate-600 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-white mb-2">No payments found</h3>
            <p className="text-slate-400">Record your first payment to get started</p>
          </div>
        )}
      </div>

      {/* Record Payment Modal */}
      {showRecordModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setShowRecordModal(false)} />
          <div className="relative bg-slate-800 rounded-xl border border-slate-700 w-full max-w-lg">
            <div className="p-5 border-b border-slate-700 flex items-center justify-between">
              <h2 className="text-xl font-semibold text-white">Record Payment</h2>
              <button
                onClick={() => setShowRecordModal(false)}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Select Deal *</label>
                <select
                  value={newPayment.deal_id}
                  onChange={(e) => setNewPayment({ ...newPayment, deal_id: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select a deal</option>
                  {deals.map(deal => {
                    const customer = customers.find(c => c.id === deal.customer_id);
                    return (
                      <option key={deal.id} value={deal.id}>
                        {deal.deal_number} - {customer?.first_name} {customer?.last_name}
                      </option>
                    );
                  })}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Payment Type</label>
                  <select
                    value={newPayment.payment_type}
                    onChange={(e) => setNewPayment({ ...newPayment, payment_type: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="down_payment">Down Payment</option>
                    <option value="monthly">Monthly Payment</option>
                    <option value="payoff">Payoff</option>
                    <option value="refund">Refund</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Amount *</label>
                  <input
                    type="number"
                    value={newPayment.amount}
                    onChange={(e) => setNewPayment({ ...newPayment, amount: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Payment Method</label>
                  <select
                    value={newPayment.payment_method}
                    onChange={(e) => setNewPayment({ ...newPayment, payment_method: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="card">Credit/Debit Card</option>
                    <option value="cash">Cash</option>
                    <option value="check">Check</option>
                    <option value="ach">ACH Transfer</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Reference #</label>
                  <input
                    type="text"
                    value={newPayment.reference_number}
                    onChange={(e) => setNewPayment({ ...newPayment, reference_number: e.target.value })}
                    placeholder="Optional"
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Notes</label>
                <textarea
                  value={newPayment.notes}
                  onChange={(e) => setNewPayment({ ...newPayment, notes: e.target.value })}
                  rows={2}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div className="p-5 border-t border-slate-700 flex justify-end gap-3">
              <button
                onClick={() => setShowRecordModal(false)}
                className="px-4 py-2 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleRecordPayment}
                disabled={!newPayment.deal_id || !newPayment.amount}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Record Payment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PaymentsView;
