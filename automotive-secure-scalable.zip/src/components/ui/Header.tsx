import React, { useState } from 'react';
import { useDealership } from '@/contexts/DealershipContext';
import { 
  Bell, 
  Search, 
  User, 
  ChevronDown,
  Settings,
  LogOut,
  Moon,
  Sun,
  Menu
} from 'lucide-react';
import { UserRole } from '@/types';

interface HeaderProps {
  onMenuToggle?: () => void;
}

const Header: React.FC<HeaderProps> = ({ onMenuToggle }) => {
  const { currentUser, currentRole, setCurrentRole, currentDealership } = useDealership();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showRoleMenu, setShowRoleMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [darkMode, setDarkMode] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  const roles: { value: UserRole; label: string }[] = [
    { value: 'super_admin', label: 'Super Admin' },
    { value: 'dealership_owner', label: 'Dealership Owner' },
    { value: 'sales_manager', label: 'Sales Manager' },
    { value: 'sales_agent', label: 'Sales Agent' },
    { value: 'accountant', label: 'Accountant' },
    { value: 'auditor', label: 'Auditor' },
  ];

  const notifications = [
    { id: 1, title: 'New deal created', message: 'Deal #DL-12345678 has been created', time: '5 min ago', unread: true },
    { id: 2, title: 'Document signed', message: 'Bill of Sale signed by customer', time: '1 hour ago', unread: true },
    { id: 3, title: 'Payment received', message: '$5,000 down payment received', time: '2 hours ago', unread: false },
    { id: 4, title: 'Vehicle sold', message: '2024 BMW X5 marked as sold', time: '3 hours ago', unread: false },
  ];

  const unreadCount = notifications.filter(n => n.unread).length;

  const getRoleColor = (role: UserRole) => {
    const colors: Record<UserRole, string> = {
      super_admin: 'bg-purple-500/20 text-purple-400',
      dealership_owner: 'bg-blue-500/20 text-blue-400',
      sales_manager: 'bg-emerald-500/20 text-emerald-400',
      sales_agent: 'bg-amber-500/20 text-amber-400',
      accountant: 'bg-cyan-500/20 text-cyan-400',
      auditor: 'bg-slate-500/20 text-slate-400',
    };
    return colors[role];
  };

  return (
    <header className="h-16 bg-slate-800 border-b border-slate-700 flex items-center justify-between px-6">
      {/* Left Section */}
      <div className="flex items-center gap-4">
        <button 
          onClick={onMenuToggle}
          className="lg:hidden p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
        >
          <Menu className="w-5 h-5" />
        </button>
        
        {/* Search Bar */}
        <div className="relative hidden md:block">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search vehicles, customers, deals..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-80 pl-10 pr-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
          />
        </div>
      </div>

      {/* Right Section */}
      <div className="flex items-center gap-3">
        {/* Role Switcher (Demo) */}
        <div className="relative">
          <button
            onClick={() => setShowRoleMenu(!showRoleMenu)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${getRoleColor(currentRole)}`}
          >
            {roles.find(r => r.value === currentRole)?.label}
            <ChevronDown className="w-4 h-4" />
          </button>
          
          {showRoleMenu && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setShowRoleMenu(false)} />
              <div className="absolute right-0 top-full mt-2 w-48 bg-slate-800 border border-slate-700 rounded-lg shadow-xl z-50 py-1">
                <p className="px-3 py-2 text-xs text-slate-400 uppercase tracking-wider border-b border-slate-700">Switch Role (Demo)</p>
                {roles.map((role) => (
                  <button
                    key={role.value}
                    onClick={() => {
                      setCurrentRole(role.value);
                      setShowRoleMenu(false);
                    }}
                    className={`w-full text-left px-3 py-2 text-sm hover:bg-slate-700 transition-colors ${
                      currentRole === role.value ? 'text-blue-400' : 'text-slate-300'
                    }`}
                  >
                    {role.label}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Dark Mode Toggle */}
        <button
          onClick={() => setDarkMode(!darkMode)}
          className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
        >
          {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
        </button>

        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
          >
            <Bell className="w-5 h-5" />
            {unreadCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 w-5 h-5 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </button>

          {showNotifications && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setShowNotifications(false)} />
              <div className="absolute right-0 top-full mt-2 w-80 bg-slate-800 border border-slate-700 rounded-lg shadow-xl z-50">
                <div className="p-3 border-b border-slate-700 flex items-center justify-between">
                  <h3 className="font-semibold text-white">Notifications</h3>
                  <button className="text-xs text-blue-400 hover:text-blue-300">Mark all read</button>
                </div>
                <div className="max-h-80 overflow-y-auto">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-3 border-b border-slate-700 last:border-0 hover:bg-slate-700/50 transition-colors cursor-pointer ${
                        notification.unread ? 'bg-slate-700/30' : ''
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        {notification.unread && (
                          <span className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                        )}
                        <div className={notification.unread ? '' : 'ml-5'}>
                          <p className="font-medium text-white text-sm">{notification.title}</p>
                          <p className="text-slate-400 text-sm">{notification.message}</p>
                          <p className="text-slate-500 text-xs mt-1">{notification.time}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="p-3 border-t border-slate-700">
                  <button className="w-full text-center text-sm text-blue-400 hover:text-blue-300">
                    View all notifications
                  </button>
                </div>
              </div>
            </>
          )}
        </div>

        {/* User Menu */}
        <div className="relative">
          <button
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center gap-3 p-1.5 hover:bg-slate-700 rounded-lg transition-colors"
          >
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-emerald-500 rounded-full flex items-center justify-center">
              <User className="w-4 h-4 text-white" />
            </div>
            <div className="hidden md:block text-left">
              <p className="text-sm font-medium text-white">
                {currentUser?.first_name} {currentUser?.last_name}
              </p>
              <p className="text-xs text-slate-400">{currentDealership?.name}</p>
            </div>
            <ChevronDown className="w-4 h-4 text-slate-400 hidden md:block" />
          </button>

          {showUserMenu && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setShowUserMenu(false)} />
              <div className="absolute right-0 top-full mt-2 w-56 bg-slate-800 border border-slate-700 rounded-lg shadow-xl z-50 py-1">
                <div className="px-4 py-3 border-b border-slate-700">
                  <p className="font-medium text-white">{currentUser?.first_name} {currentUser?.last_name}</p>
                  <p className="text-sm text-slate-400">{currentUser?.email}</p>
                </div>
                <button className="w-full flex items-center gap-3 px-4 py-2 text-slate-300 hover:bg-slate-700 transition-colors">
                  <User className="w-4 h-4" />
                  <span>Profile</span>
                </button>
                <button className="w-full flex items-center gap-3 px-4 py-2 text-slate-300 hover:bg-slate-700 transition-colors">
                  <Settings className="w-4 h-4" />
                  <span>Settings</span>
                </button>
                <div className="border-t border-slate-700 mt-1 pt-1">
                  <button className="w-full flex items-center gap-3 px-4 py-2 text-red-400 hover:bg-slate-700 transition-colors">
                    <LogOut className="w-4 h-4" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
