import React from 'react';
import { useDealership } from '@/contexts/DealershipContext';
import { 
  LayoutDashboard, 
  Car, 
  Users, 
  FileText, 
  DollarSign, 
  Settings, 
  BarChart3, 
  Shield, 
  Building2,
  ChevronLeft,
  ChevronRight,
  LogOut,
  CreditCard,
  Handshake
} from 'lucide-react';

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ collapsed, onToggle }) => {
  const { activeView, setActiveView, currentRole, currentDealership } = useDealership();

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['super_admin', 'dealership_owner', 'sales_manager', 'sales_agent', 'accountant', 'auditor'] },
    { id: 'inventory', label: 'Inventory', icon: Car, roles: ['super_admin', 'dealership_owner', 'sales_manager', 'sales_agent', 'auditor'] },
    { id: 'customers', label: 'Customers', icon: Users, roles: ['super_admin', 'dealership_owner', 'sales_manager', 'sales_agent'] },
    { id: 'deals', label: 'Deals', icon: Handshake, roles: ['super_admin', 'dealership_owner', 'sales_manager', 'sales_agent', 'accountant', 'auditor'] },
    { id: 'documents', label: 'Documents', icon: FileText, roles: ['super_admin', 'dealership_owner', 'sales_manager', 'sales_agent', 'accountant', 'auditor'] },
    { id: 'payments', label: 'Payments', icon: DollarSign, roles: ['super_admin', 'dealership_owner', 'sales_manager', 'accountant'] },
    { id: 'reports', label: 'Reports', icon: BarChart3, roles: ['super_admin', 'dealership_owner', 'sales_manager', 'accountant', 'auditor'] },
    { id: 'subscription', label: 'Subscription', icon: CreditCard, roles: ['super_admin', 'dealership_owner'] },
    { id: 'settings', label: 'Settings', icon: Settings, roles: ['super_admin', 'dealership_owner', 'sales_manager'] },
  ];

  const adminItems = [
    { id: 'admin', label: 'Admin Panel', icon: Shield, roles: ['super_admin'] },
    { id: 'dealerships', label: 'Dealerships', icon: Building2, roles: ['super_admin'] },
  ];

  const filteredMenuItems = menuItems.filter(item => item.roles.includes(currentRole));
  const filteredAdminItems = adminItems.filter(item => item.roles.includes(currentRole));

  return (
    <aside 
      className={`fixed left-0 top-0 h-full bg-slate-900 text-white transition-all duration-300 z-40 flex flex-col ${
        collapsed ? 'w-20' : 'w-64'
      }`}
    >
      {/* Logo */}
      <div className="h-16 flex items-center justify-between px-4 border-b border-slate-700">
        {!collapsed && (
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-emerald-500 rounded-lg flex items-center justify-center">
              <Car className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-lg leading-tight">DealerPro</h1>
              <p className="text-xs text-slate-400">SaaS Platform</p>
            </div>
          </div>
        )}
        {collapsed && (
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-emerald-500 rounded-lg flex items-center justify-center mx-auto">
            <Car className="w-6 h-6 text-white" />
          </div>
        )}
      </div>

      {/* Dealership Info */}
      {currentDealership && !collapsed && (
        <div className="px-4 py-3 border-b border-slate-700">
          <p className="text-xs text-slate-400 uppercase tracking-wider">Current Dealership</p>
          <p className="font-medium text-sm truncate">{currentDealership.name}</p>
          <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium mt-1 ${
            currentDealership.subscription_status === 'active' 
              ? 'bg-emerald-500/20 text-emerald-400' 
              : currentDealership.subscription_status === 'trial'
              ? 'bg-blue-500/20 text-blue-400'
              : 'bg-amber-500/20 text-amber-400'
          }`}>
            {currentDealership.subscription_status === 'active' ? 'Active' : 
             currentDealership.subscription_status === 'trial' ? 'Trial' : 'Inactive'}
          </span>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4">
        <ul className="space-y-1 px-3">
          {filteredMenuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.id;
            return (
              <li key={item.id}>
                <button
                  onClick={() => setActiveView(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 ${
                    isActive 
                      ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30' 
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                  title={collapsed ? item.label : undefined}
                >
                  <Icon className={`w-5 h-5 flex-shrink-0 ${collapsed ? 'mx-auto' : ''}`} />
                  {!collapsed && <span className="font-medium">{item.label}</span>}
                </button>
              </li>
            );
          })}
        </ul>

        {filteredAdminItems.length > 0 && (
          <>
            <div className={`px-6 py-3 ${collapsed ? 'hidden' : ''}`}>
              <p className="text-xs text-slate-500 uppercase tracking-wider">Administration</p>
            </div>
            <ul className="space-y-1 px-3">
              {filteredAdminItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeView === item.id;
                return (
                  <li key={item.id}>
                    <button
                      onClick={() => setActiveView(item.id)}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 ${
                        isActive 
                          ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30' 
                          : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                      }`}
                      title={collapsed ? item.label : undefined}
                    >
                      <Icon className={`w-5 h-5 flex-shrink-0 ${collapsed ? 'mx-auto' : ''}`} />
                      {!collapsed && <span className="font-medium">{item.label}</span>}
                    </button>
                  </li>
                );
              })}
            </ul>
          </>
        )}
      </nav>

      {/* Toggle Button */}
      <button
        onClick={onToggle}
        className="absolute -right-3 top-20 w-6 h-6 bg-slate-700 rounded-full flex items-center justify-center text-slate-300 hover:bg-slate-600 hover:text-white transition-colors shadow-lg"
      >
        {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
      </button>

      {/* User Section */}
      <div className="border-t border-slate-700 p-4">
        <button className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-slate-300 hover:bg-slate-800 hover:text-white transition-colors ${collapsed ? 'justify-center' : ''}`}>
          <LogOut className="w-5 h-5" />
          {!collapsed && <span className="font-medium">Sign Out</span>}
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
