import React, { useState } from 'react';
import { 
  Shield, 
  Building2, 
  Users, 
  DollarSign, 
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Clock,
  Activity,
  Server,
  Database,
  Cpu,
  HardDrive,
  Search,
  Filter,
  MoreVertical,
  Eye,
  Ban,
  RefreshCw
} from 'lucide-react';

const AdminView: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');

  // Mock data for admin dashboard
  const platformStats = {
    totalDealerships: 127,
    activeSubscriptions: 98,
    trialAccounts: 24,
    canceledAccounts: 5,
    mrr: 24500,
    arr: 294000,
    avgRevenuePerUser: 250,
    churnRate: 2.3,
  };

  const systemHealth = {
    apiLatency: 45,
    uptime: 99.98,
    activeConnections: 342,
    cpuUsage: 34,
    memoryUsage: 62,
    storageUsage: 45,
  };

  const recentDealerships = [
    { id: 1, name: 'Premier Auto Sales', plan: 'Professional', status: 'active', mrr: 249, users: 8, vehicles: 45 },
    { id: 2, name: 'City Motors', plan: 'Starter', status: 'trial', mrr: 0, users: 2, vehicles: 12 },
    { id: 3, name: 'Luxury Car Hub', plan: 'Enterprise', status: 'active', mrr: 499, users: 15, vehicles: 120 },
    { id: 4, name: 'Budget Auto Center', plan: 'Starter', status: 'active', mrr: 99, users: 2, vehicles: 20 },
    { id: 5, name: 'Elite Vehicles', plan: 'Professional', status: 'past_due', mrr: 249, users: 6, vehicles: 35 },
  ];

  const auditLogs = [
    { id: 1, action: 'User Login', user: 'john@premierauto.com', dealership: 'Premier Auto Sales', time: '2 min ago', ip: '192.168.1.1' },
    { id: 2, action: 'Vehicle Added', user: 'sarah@citymotors.com', dealership: 'City Motors', time: '15 min ago', ip: '10.0.0.45' },
    { id: 3, action: 'Deal Created', user: 'mike@luxurycarhub.com', dealership: 'Luxury Car Hub', time: '32 min ago', ip: '172.16.0.100' },
    { id: 4, action: 'Document Signed', user: 'emily@budgetauto.com', dealership: 'Budget Auto Center', time: '1 hour ago', ip: '192.168.2.50' },
    { id: 5, action: 'Payment Failed', user: 'admin@elitevehicles.com', dealership: 'Elite Vehicles', time: '2 hours ago', ip: '10.10.10.10' },
  ];

  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'dealerships', label: 'Dealerships' },
    { id: 'revenue', label: 'Revenue' },
    { id: 'system', label: 'System Health' },
    { id: 'audit', label: 'Audit Logs' },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-emerald-500/20 text-emerald-400';
      case 'trial': return 'bg-blue-500/20 text-blue-400';
      case 'past_due': return 'bg-red-500/20 text-red-400';
      case 'canceled': return 'bg-slate-500/20 text-slate-400';
      default: return 'bg-slate-500/20 text-slate-400';
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center">
          <Shield className="w-6 h-6 text-purple-400" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">Admin Dashboard</h1>
          <p className="text-slate-400">Platform administration and monitoring</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-slate-700 pb-4">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              activeTab === tab.id
                ? 'bg-purple-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-700'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
              <div className="flex items-center justify-between mb-3">
                <Building2 className="w-8 h-8 text-blue-400" />
                <span className="text-xs text-emerald-400">+12 this month</span>
              </div>
              <p className="text-3xl font-bold text-white">{platformStats.totalDealerships}</p>
              <p className="text-sm text-slate-400">Total Dealerships</p>
            </div>
            <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
              <div className="flex items-center justify-between mb-3">
                <CheckCircle className="w-8 h-8 text-emerald-400" />
                <span className="text-xs text-emerald-400">77% conversion</span>
              </div>
              <p className="text-3xl font-bold text-white">{platformStats.activeSubscriptions}</p>
              <p className="text-sm text-slate-400">Active Subscriptions</p>
            </div>
            <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
              <div className="flex items-center justify-between mb-3">
                <DollarSign className="w-8 h-8 text-purple-400" />
                <span className="text-xs text-emerald-400">+8% MoM</span>
              </div>
              <p className="text-3xl font-bold text-white">${platformStats.mrr.toLocaleString()}</p>
              <p className="text-sm text-slate-400">Monthly Recurring Revenue</p>
            </div>
            <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
              <div className="flex items-center justify-between mb-3">
                <TrendingUp className="w-8 h-8 text-amber-400" />
                <span className="text-xs text-red-400">{platformStats.churnRate}%</span>
              </div>
              <p className="text-3xl font-bold text-white">${platformStats.arr.toLocaleString()}</p>
              <p className="text-sm text-slate-400">Annual Run Rate</p>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Recent Dealerships */}
            <div className="bg-slate-800 rounded-xl border border-slate-700">
              <div className="p-5 border-b border-slate-700 flex items-center justify-between">
                <h2 className="text-lg font-semibold text-white">Recent Dealerships</h2>
                <button className="text-sm text-purple-400 hover:text-purple-300">View All</button>
              </div>
              <div className="divide-y divide-slate-700">
                {recentDealerships.slice(0, 4).map((dealership) => (
                  <div key={dealership.id} className="p-4 hover:bg-slate-700/30 transition-colors">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-white">{dealership.name}</p>
                        <p className="text-sm text-slate-400">{dealership.plan} • {dealership.users} users</p>
                      </div>
                      <span className={`px-2 py-1 rounded text-xs font-medium ${getStatusColor(dealership.status)}`}>
                        {dealership.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* System Status */}
            <div className="bg-slate-800 rounded-xl border border-slate-700">
              <div className="p-5 border-b border-slate-700 flex items-center justify-between">
                <h2 className="text-lg font-semibold text-white">System Status</h2>
                <span className="flex items-center gap-2 text-sm text-emerald-400">
                  <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
                  All Systems Operational
                </span>
              </div>
              <div className="p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Activity className="w-5 h-5 text-slate-400" />
                    <span className="text-slate-300">API Latency</span>
                  </div>
                  <span className="text-white font-medium">{systemHealth.apiLatency}ms</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Server className="w-5 h-5 text-slate-400" />
                    <span className="text-slate-300">Uptime</span>
                  </div>
                  <span className="text-emerald-400 font-medium">{systemHealth.uptime}%</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Users className="w-5 h-5 text-slate-400" />
                    <span className="text-slate-300">Active Connections</span>
                  </div>
                  <span className="text-white font-medium">{systemHealth.activeConnections}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Cpu className="w-5 h-5 text-slate-400" />
                    <span className="text-slate-300">CPU Usage</span>
                  </div>
                  <span className="text-white font-medium">{systemHealth.cpuUsage}%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Dealerships Tab */}
      {activeTab === 'dealerships' && (
        <div className="bg-slate-800 rounded-xl border border-slate-700">
          <div className="p-5 border-b border-slate-700 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <h2 className="text-lg font-semibold text-white">All Dealerships</h2>
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search dealerships..."
                  className="pl-10 pr-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <button className="p-2 bg-slate-700 text-slate-300 rounded-lg hover:bg-slate-600 transition-colors">
                <Filter className="w-4 h-4" />
              </button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-700/50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase">Dealership</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase">Plan</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase">Status</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase">MRR</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase">Users</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase">Vehicles</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700">
                {recentDealerships.map((dealership) => (
                  <tr key={dealership.id} className="hover:bg-slate-700/30 transition-colors">
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center text-white font-medium">
                          {dealership.name.charAt(0)}
                        </div>
                        <span className="font-medium text-white">{dealership.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-4 text-slate-300">{dealership.plan}</td>
                    <td className="px-4 py-4">
                      <span className={`px-2 py-1 rounded text-xs font-medium ${getStatusColor(dealership.status)}`}>
                        {dealership.status}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-white font-medium">${dealership.mrr}</td>
                    <td className="px-4 py-4 text-slate-300">{dealership.users}</td>
                    <td className="px-4 py-4 text-slate-300">{dealership.vehicles}</td>
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-2">
                        <button className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-700 rounded transition-colors">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-700 rounded transition-colors">
                          <Ban className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* System Health Tab */}
      {activeTab === 'system' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
              <div className="flex items-center gap-3 mb-4">
                <Cpu className="w-6 h-6 text-blue-400" />
                <span className="font-medium text-white">CPU Usage</span>
              </div>
              <p className="text-3xl font-bold text-white mb-2">{systemHealth.cpuUsage}%</p>
              <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-blue-500 rounded-full"
                  style={{ width: `${systemHealth.cpuUsage}%` }}
                />
              </div>
            </div>
            <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
              <div className="flex items-center gap-3 mb-4">
                <Database className="w-6 h-6 text-emerald-400" />
                <span className="font-medium text-white">Memory Usage</span>
              </div>
              <p className="text-3xl font-bold text-white mb-2">{systemHealth.memoryUsage}%</p>
              <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-emerald-500 rounded-full"
                  style={{ width: `${systemHealth.memoryUsage}%` }}
                />
              </div>
            </div>
            <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
              <div className="flex items-center gap-3 mb-4">
                <HardDrive className="w-6 h-6 text-purple-400" />
                <span className="font-medium text-white">Storage Usage</span>
              </div>
              <p className="text-3xl font-bold text-white mb-2">{systemHealth.storageUsage}%</p>
              <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-purple-500 rounded-full"
                  style={{ width: `${systemHealth.storageUsage}%` }}
                />
              </div>
            </div>
          </div>

          <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-white">Service Status</h2>
              <button className="text-sm text-purple-400 hover:text-purple-300 flex items-center gap-1">
                <RefreshCw className="w-4 h-4" />
                Refresh
              </button>
            </div>
            <div className="space-y-3">
              {[
                { name: 'API Gateway', status: 'operational', latency: '45ms' },
                { name: 'Database', status: 'operational', latency: '12ms' },
                { name: 'Redis Cache', status: 'operational', latency: '2ms' },
                { name: 'File Storage', status: 'operational', latency: '89ms' },
                { name: 'Email Service', status: 'operational', latency: '156ms' },
                { name: 'PDF Generator', status: 'operational', latency: '234ms' },
              ].map((service, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <span className="w-2 h-2 bg-emerald-400 rounded-full" />
                    <span className="text-white">{service.name}</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-sm text-slate-400">{service.latency}</span>
                    <span className="text-sm text-emerald-400">{service.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Audit Logs Tab */}
      {activeTab === 'audit' && (
        <div className="bg-slate-800 rounded-xl border border-slate-700">
          <div className="p-5 border-b border-slate-700 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <h2 className="text-lg font-semibold text-white">Audit Logs</h2>
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search logs..."
                  className="pl-10 pr-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
            </div>
          </div>
          <div className="divide-y divide-slate-700">
            {auditLogs.map((log) => (
              <div key={log.id} className="p-4 hover:bg-slate-700/30 transition-colors">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-white">{log.action}</p>
                    <p className="text-sm text-slate-400">
                      {log.user} • {log.dealership}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-slate-400">{log.time}</p>
                    <p className="text-xs text-slate-500 font-mono">{log.ip}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Revenue Tab */}
      {activeTab === 'revenue' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
              <p className="text-sm text-slate-400 mb-1">Monthly Recurring Revenue</p>
              <p className="text-2xl font-bold text-white">${platformStats.mrr.toLocaleString()}</p>
            </div>
            <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
              <p className="text-sm text-slate-400 mb-1">Annual Run Rate</p>
              <p className="text-2xl font-bold text-white">${platformStats.arr.toLocaleString()}</p>
            </div>
            <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
              <p className="text-sm text-slate-400 mb-1">Avg Revenue Per User</p>
              <p className="text-2xl font-bold text-white">${platformStats.avgRevenuePerUser}</p>
            </div>
            <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
              <p className="text-sm text-slate-400 mb-1">Churn Rate</p>
              <p className="text-2xl font-bold text-red-400">{platformStats.churnRate}%</p>
            </div>
          </div>

          <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
            <h2 className="text-lg font-semibold text-white mb-4">Revenue by Plan</h2>
            <div className="space-y-4">
              {[
                { plan: 'Enterprise', count: 15, mrr: 7485, percentage: 30 },
                { plan: 'Professional', count: 58, mrr: 14442, percentage: 59 },
                { plan: 'Starter', count: 25, mrr: 2475, percentage: 11 },
              ].map((item) => (
                <div key={item.plan}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-slate-300">{item.plan}</span>
                    <span className="text-white font-medium">${item.mrr.toLocaleString()} ({item.count} accounts)</span>
                  </div>
                  <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-purple-500 rounded-full"
                      style={{ width: `${item.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminView;
