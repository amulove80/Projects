import React, { useState, useMemo } from 'react';
import { useDealership } from '@/contexts/DealershipContext';
import { Deal, DealStatus, Customer, Vehicle } from '@/types';
import { 
  Handshake, 
  Plus, 
  Search, 
  X,
  ChevronDown,
  DollarSign,
  User,
  Car,
  FileText,
  Clock,
  CheckCircle,
  AlertCircle,
  ArrowRight
} from 'lucide-react';

const DealsView: React.FC = () => {
  const { deals, customers, vehicles, addDeal, updateDeal } = useDealership();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [viewMode, setViewMode] = useState<'kanban' | 'list'>('kanban');

  const [newDeal, setNewDeal] = useState({
    customer_id: '',
    vehicle_id: '',
    vehicle_price: 0,
    down_payment: 0,
    trade_in_value: 0,
    tax_rate: 0.0725,
    doc_fee: 299,
    title_fee: 75,
    registration_fee: 250,
    deal_type: 'retail' as const,
    notes: '',
  });

  const dealStatuses: { id: DealStatus; label: string; color: string }[] = [
    { id: 'lead', label: 'Lead', color: 'bg-slate-500' },
    { id: 'quote', label: 'Quote', color: 'bg-cyan-500' },
    { id: 'negotiation', label: 'Negotiation', color: 'bg-amber-500' },
    { id: 'paperwork', label: 'Paperwork', color: 'bg-blue-500' },
    { id: 'financing', label: 'Financing', color: 'bg-purple-500' },
    { id: 'closed', label: 'Closed', color: 'bg-emerald-500' },
  ];

  const filteredDeals = useMemo(() => {
    return deals.filter(deal => {
      const matchesSearch = deal.deal_number?.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === 'all' || deal.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [deals, searchQuery, statusFilter]);

  const dealsByStatus = useMemo(() => {
    const grouped: Record<DealStatus, Deal[]> = {
      lead: [],
      quote: [],
      negotiation: [],
      paperwork: [],
      financing: [],
      closed: [],
      lost: [],
    };
    
    filteredDeals.forEach(deal => {
      if (grouped[deal.status]) {
        grouped[deal.status].push(deal);
      }
    });
    
    return grouped;
  }, [filteredDeals]);

  const availableVehicles = vehicles.filter(v => v.status === 'available');

  const calculateTotals = () => {
    const selectedVehicle = vehicles.find(v => v.id === newDeal.vehicle_id);
    const vehiclePrice = selectedVehicle?.listing_price || newDeal.vehicle_price;
    const taxableAmount = vehiclePrice - newDeal.trade_in_value;
    const taxAmount = taxableAmount * newDeal.tax_rate;
    const totalFees = newDeal.doc_fee + newDeal.title_fee + newDeal.registration_fee;
    const subtotal = vehiclePrice + taxAmount + totalFees - newDeal.trade_in_value;
    const amountFinanced = subtotal - newDeal.down_payment;
    
    return {
      vehiclePrice,
      taxAmount,
      totalFees,
      subtotal,
      amountFinanced,
    };
  };

  const handleAddDeal = async () => {
    if (!newDeal.customer_id || !newDeal.vehicle_id) return;
    
    const totals = calculateTotals();
    
    await addDeal({
      customer_id: newDeal.customer_id,
      vehicle_id: newDeal.vehicle_id,
      status: 'lead',
      deal_type: newDeal.deal_type,
      vehicle_price: totals.vehiclePrice,
      trade_in_value: newDeal.trade_in_value,
      trade_in_payoff: 0,
      down_payment: newDeal.down_payment,
      tax_rate: newDeal.tax_rate,
      tax_amount: totals.taxAmount,
      doc_fee: newDeal.doc_fee,
      title_fee: newDeal.title_fee,
      registration_fee: newDeal.registration_fee,
      other_fees: 0,
      total_fees: totals.totalFees,
      subtotal: totals.subtotal,
      total_price: totals.subtotal,
      amount_financed: totals.amountFinanced,
      apr: 0,
      term_months: 0,
      monthly_payment: 0,
      notes: newDeal.notes,
    });
    
    setShowAddModal(false);
    setNewDeal({
      customer_id: '',
      vehicle_id: '',
      vehicle_price: 0,
      down_payment: 0,
      trade_in_value: 0,
      tax_rate: 0.0725,
      doc_fee: 299,
      title_fee: 75,
      registration_fee: 250,
      deal_type: 'retail',
      notes: '',
    });
  };

  const handleStatusChange = async (dealId: string, newStatus: DealStatus) => {
    await updateDeal(dealId, { 
      status: newStatus,
      ...(newStatus === 'closed' ? { closed_at: new Date().toISOString() } : {}),
    });
  };

  const getCustomerName = (customerId: string) => {
    const customer = customers.find(c => c.id === customerId);
    return customer ? `${customer.first_name} ${customer.last_name}` : 'Unknown';
  };

  const getVehicleInfo = (vehicleId: string) => {
    const vehicle = vehicles.find(v => v.id === vehicleId);
    return vehicle ? `${vehicle.year} ${vehicle.make} ${vehicle.model}` : 'Unknown';
  };

  const getStatusColor = (status: DealStatus) => {
    const statusObj = dealStatuses.find(s => s.id === status);
    return statusObj?.color || 'bg-slate-500';
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Deal Pipeline</h1>
          <p className="text-slate-400">{filteredDeals.length} active deals</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center bg-slate-700 rounded-lg p-1">
            <button
              onClick={() => setViewMode('kanban')}
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                viewMode === 'kanban' ? 'bg-slate-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Kanban
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                viewMode === 'list' ? 'bg-slate-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              List
            </button>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            New Deal
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-slate-800 rounded-xl border border-slate-700 p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search by deal number..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="relative">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="appearance-none px-4 py-2 pr-10 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Status</option>
              {dealStatuses.map(status => (
                <option key={status.id} value={status.id}>{status.label}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Kanban View */}
      {viewMode === 'kanban' && (
        <div className="flex gap-4 overflow-x-auto pb-4">
          {dealStatuses.filter(s => s.id !== 'lost').map((status) => (
            <div key={status.id} className="flex-shrink-0 w-80">
              <div className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden">
                <div className="p-4 border-b border-slate-700 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${status.color}`} />
                    <h3 className="font-semibold text-white">{status.label}</h3>
                  </div>
                  <span className="text-sm text-slate-400">
                    {dealsByStatus[status.id].length}
                  </span>
                </div>
                <div className="p-3 space-y-3 max-h-[calc(100vh-350px)] overflow-y-auto">
                  {dealsByStatus[status.id].map((deal) => (
                    <div
                      key={deal.id}
                      className="bg-slate-700/50 rounded-lg p-4 hover:bg-slate-700 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-mono text-slate-400">{deal.deal_number}</span>
                        <span className="text-sm font-semibold text-emerald-400">
                          ${deal.total_price?.toLocaleString()}
                        </span>
                      </div>
                      <p className="font-medium text-white mb-1">
                        {getCustomerName(deal.customer_id)}
                      </p>
                      <p className="text-sm text-slate-400 mb-3">
                        {getVehicleInfo(deal.vehicle_id)}
                      </p>
                      {status.id !== 'closed' && (
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              const currentIndex = dealStatuses.findIndex(s => s.id === deal.status);
                              if (currentIndex < dealStatuses.length - 2) {
                                handleStatusChange(deal.id, dealStatuses[currentIndex + 1].id);
                              }
                            }}
                            className="flex-1 px-3 py-1.5 bg-slate-600 text-white text-sm rounded hover:bg-slate-500 transition-colors flex items-center justify-center gap-1"
                          >
                            Move <ArrowRight className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                  {dealsByStatus[status.id].length === 0 && (
                    <div className="text-center py-8 text-slate-500">
                      <Handshake className="w-8 h-8 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">No deals</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* List View */}
      {viewMode === 'list' && (
        <div className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden">
          <table className="w-full">
            <thead className="bg-slate-700/50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Deal #</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Customer</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Vehicle</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Total</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Status</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Created</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700">
              {filteredDeals.map((deal) => (
                <tr key={deal.id} className="hover:bg-slate-700/30 transition-colors">
                  <td className="px-4 py-4 font-mono text-white">{deal.deal_number}</td>
                  <td className="px-4 py-4 text-white">{getCustomerName(deal.customer_id)}</td>
                  <td className="px-4 py-4 text-slate-300">{getVehicleInfo(deal.vehicle_id)}</td>
                  <td className="px-4 py-4 text-emerald-400 font-semibold">${deal.total_price?.toLocaleString()}</td>
                  <td className="px-4 py-4">
                    <span className={`inline-flex items-center px-2 py-1 rounded text-xs font-medium ${getStatusColor(deal.status)} bg-opacity-20 text-white`}>
                      <span className={`w-2 h-2 rounded-full ${getStatusColor(deal.status)} mr-2`} />
                      {dealStatuses.find(s => s.id === deal.status)?.label}
                    </span>
                  </td>
                  <td className="px-4 py-4 text-slate-400 text-sm">
                    {new Date(deal.created_at).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredDeals.length === 0 && (
            <div className="p-12 text-center">
              <Handshake className="w-16 h-16 text-slate-600 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">No deals found</h3>
              <p className="text-slate-400 mb-4">Create your first deal to get started</p>
              <button
                onClick={() => setShowAddModal(true)}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors"
              >
                Create Deal
              </button>
            </div>
          )}
        </div>
      )}

      {/* Add Deal Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setShowAddModal(false)} />
          <div className="relative bg-slate-800 rounded-xl border border-slate-700 w-full max-w-3xl max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-slate-800 p-5 border-b border-slate-700 flex items-center justify-between">
              <h2 className="text-xl font-semibold text-white">Create New Deal</h2>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-5 space-y-6">
              {/* Customer & Vehicle Selection */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">
                    <User className="w-4 h-4 inline mr-2" />
                    Customer *
                  </label>
                  <select
                    value={newDeal.customer_id}
                    onChange={(e) => setNewDeal({ ...newDeal, customer_id: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Select customer</option>
                    {customers.map(customer => (
                      <option key={customer.id} value={customer.id}>
                        {customer.first_name} {customer.last_name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">
                    <Car className="w-4 h-4 inline mr-2" />
                    Vehicle *
                  </label>
                  <select
                    value={newDeal.vehicle_id}
                    onChange={(e) => {
                      const vehicle = vehicles.find(v => v.id === e.target.value);
                      setNewDeal({ 
                        ...newDeal, 
                        vehicle_id: e.target.value,
                        vehicle_price: vehicle?.listing_price || 0,
                      });
                    }}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Select vehicle</option>
                    {availableVehicles.map(vehicle => (
                      <option key={vehicle.id} value={vehicle.id}>
                        {vehicle.year} {vehicle.make} {vehicle.model} - ${vehicle.listing_price?.toLocaleString()}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Pricing */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
                  <DollarSign className="w-5 h-5" />
                  Pricing Details
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Vehicle Price</label>
                    <input
                      type="number"
                      value={newDeal.vehicle_price || calculateTotals().vehiclePrice}
                      onChange={(e) => setNewDeal({ ...newDeal, vehicle_price: parseFloat(e.target.value) || 0 })}
                      className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Down Payment</label>
                    <input
                      type="number"
                      value={newDeal.down_payment}
                      onChange={(e) => setNewDeal({ ...newDeal, down_payment: parseFloat(e.target.value) || 0 })}
                      className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Trade-In Value</label>
                    <input
                      type="number"
                      value={newDeal.trade_in_value}
                      onChange={(e) => setNewDeal({ ...newDeal, trade_in_value: parseFloat(e.target.value) || 0 })}
                      className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Tax Rate (%)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={(newDeal.tax_rate * 100).toFixed(2)}
                      onChange={(e) => setNewDeal({ ...newDeal, tax_rate: parseFloat(e.target.value) / 100 || 0 })}
                      className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Doc Fee</label>
                    <input
                      type="number"
                      value={newDeal.doc_fee}
                      onChange={(e) => setNewDeal({ ...newDeal, doc_fee: parseFloat(e.target.value) || 0 })}
                      className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Title Fee</label>
                    <input
                      type="number"
                      value={newDeal.title_fee}
                      onChange={(e) => setNewDeal({ ...newDeal, title_fee: parseFloat(e.target.value) || 0 })}
                      className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>

              {/* Deal Summary */}
              <div className="bg-slate-700/50 rounded-lg p-4">
                <h4 className="font-semibold text-white mb-3">Deal Summary</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Vehicle Price</span>
                    <span className="text-white">${calculateTotals().vehiclePrice.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Trade-In Value</span>
                    <span className="text-emerald-400">-${newDeal.trade_in_value.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Tax ({(newDeal.tax_rate * 100).toFixed(2)}%)</span>
                    <span className="text-white">${calculateTotals().taxAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Fees</span>
                    <span className="text-white">${calculateTotals().totalFees.toLocaleString()}</span>
                  </div>
                  <div className="border-t border-slate-600 pt-2 mt-2">
                    <div className="flex justify-between font-semibold">
                      <span className="text-white">Total</span>
                      <span className="text-emerald-400">${calculateTotals().subtotal.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Down Payment</span>
                      <span className="text-white">-${newDeal.down_payment.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between font-semibold mt-2">
                      <span className="text-white">Amount to Finance</span>
                      <span className="text-blue-400">${calculateTotals().amountFinanced.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Notes</label>
                <textarea
                  value={newDeal.notes}
                  onChange={(e) => setNewDeal({ ...newDeal, notes: e.target.value })}
                  rows={3}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div className="sticky bottom-0 bg-slate-800 p-5 border-t border-slate-700 flex justify-end gap-3">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleAddDeal}
                disabled={!newDeal.customer_id || !newDeal.vehicle_id}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Create Deal
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DealsView;
