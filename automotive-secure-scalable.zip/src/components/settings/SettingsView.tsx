import React, { useState } from 'react';
import { useDealership } from '@/contexts/DealershipContext';
import { 
  Settings, 
  Building2, 
  Users, 
  Shield, 
  Bell, 
  Palette,
  Save,
  Upload,
  Eye,
  EyeOff,
  Plus,
  Trash2,
  Edit
} from 'lucide-react';

const SettingsView: React.FC = () => {
  const { currentDealership, currentUser } = useDealership();
  const [activeTab, setActiveTab] = useState('dealership');
  const [showPassword, setShowPassword] = useState(false);

  const [dealershipSettings, setDealershipSettings] = useState({
    name: currentDealership?.name || '',
    license_number: currentDealership?.license_number || '',
    address: currentDealership?.address || '',
    city: currentDealership?.city || '',
    state: currentDealership?.state || '',
    zip_code: currentDealership?.zip_code || '',
    phone: currentDealership?.phone || '',
    email: currentDealership?.email || '',
    website: currentDealership?.website || '',
    tax_id: currentDealership?.tax_id || '',
    primary_color: currentDealership?.primary_color || '#1e40af',
    secondary_color: currentDealership?.secondary_color || '#10b981',
  });

  const [userSettings, setUserSettings] = useState({
    first_name: currentUser?.first_name || '',
    last_name: currentUser?.last_name || '',
    email: currentUser?.email || '',
    phone: currentUser?.phone || '',
    current_password: '',
    new_password: '',
    confirm_password: '',
  });

  const [notifications, setNotifications] = useState({
    email_deals: true,
    email_documents: true,
    email_payments: false,
    email_reports: true,
    push_deals: true,
    push_documents: false,
  });

  const tabs = [
    { id: 'dealership', label: 'Dealership', icon: Building2 },
    { id: 'profile', label: 'Profile', icon: Users },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'branding', label: 'Branding', icon: Palette },
  ];

  const teamMembers = [
    { id: 1, name: 'John Smith', email: 'john@example.com', role: 'Dealership Owner', status: 'active' },
    { id: 2, name: 'Sarah Johnson', email: 'sarah@example.com', role: 'Sales Manager', status: 'active' },
    { id: 3, name: 'Mike Wilson', email: 'mike@example.com', role: 'Sales Agent', status: 'active' },
    { id: 4, name: 'Emily Davis', email: 'emily@example.com', role: 'Accountant', status: 'pending' },
  ];

  const handleSave = () => {
    alert('Settings saved successfully! (Demo)');
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">Settings</h1>
        <p className="text-slate-400">Manage your dealership and account settings</p>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-slate-700 pb-4">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                activeTab === tab.id
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-white hover:bg-slate-700'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Dealership Settings */}
      {activeTab === 'dealership' && (
        <div className="bg-slate-800 rounded-xl border border-slate-700 p-6">
          <h2 className="text-lg font-semibold text-white mb-6">Dealership Information</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Dealership Name</label>
              <input
                type="text"
                value={dealershipSettings.name}
                onChange={(e) => setDealershipSettings({ ...dealershipSettings, name: e.target.value })}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Dealer License #</label>
              <input
                type="text"
                value={dealershipSettings.license_number}
                onChange={(e) => setDealershipSettings({ ...dealershipSettings, license_number: e.target.value })}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-300 mb-1">Address</label>
              <input
                type="text"
                value={dealershipSettings.address}
                onChange={(e) => setDealershipSettings({ ...dealershipSettings, address: e.target.value })}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">City</label>
              <input
                type="text"
                value={dealershipSettings.city}
                onChange={(e) => setDealershipSettings({ ...dealershipSettings, city: e.target.value })}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">State</label>
                <input
                  type="text"
                  value={dealershipSettings.state}
                  onChange={(e) => setDealershipSettings({ ...dealershipSettings, state: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">ZIP Code</label>
                <input
                  type="text"
                  value={dealershipSettings.zip_code}
                  onChange={(e) => setDealershipSettings({ ...dealershipSettings, zip_code: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Phone</label>
              <input
                type="tel"
                value={dealershipSettings.phone}
                onChange={(e) => setDealershipSettings({ ...dealershipSettings, phone: e.target.value })}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Email</label>
              <input
                type="email"
                value={dealershipSettings.email}
                onChange={(e) => setDealershipSettings({ ...dealershipSettings, email: e.target.value })}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Website</label>
              <input
                type="url"
                value={dealershipSettings.website}
                onChange={(e) => setDealershipSettings({ ...dealershipSettings, website: e.target.value })}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Tax ID</label>
              <input
                type="text"
                value={dealershipSettings.tax_id}
                onChange={(e) => setDealershipSettings({ ...dealershipSettings, tax_id: e.target.value })}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Team Members */}
          <div className="mt-8">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">Team Members</h3>
              <button className="px-3 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors flex items-center gap-2 text-sm">
                <Plus className="w-4 h-4" />
                Invite User
              </button>
            </div>
            <div className="space-y-3">
              {teamMembers.map((member) => (
                <div key={member.id} className="flex items-center justify-between p-4 bg-slate-700/50 rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-emerald-500 rounded-full flex items-center justify-center text-white font-medium">
                      {member.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div>
                      <p className="font-medium text-white">{member.name}</p>
                      <p className="text-sm text-slate-400">{member.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-sm text-slate-300">{member.role}</span>
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      member.status === 'active' 
                        ? 'bg-emerald-500/20 text-emerald-400' 
                        : 'bg-amber-500/20 text-amber-400'
                    }`}>
                      {member.status}
                    </span>
                    <button className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-600 rounded transition-colors">
                      <Edit className="w-4 h-4" />
                    </button>
                    <button className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-600 rounded transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 flex justify-end">
            <button
              onClick={handleSave}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              Save Changes
            </button>
          </div>
        </div>
      )}

      {/* Profile Settings */}
      {activeTab === 'profile' && (
        <div className="bg-slate-800 rounded-xl border border-slate-700 p-6">
          <h2 className="text-lg font-semibold text-white mb-6">Profile Settings</h2>
          <div className="flex items-center gap-6 mb-6">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-emerald-500 rounded-full flex items-center justify-center text-white text-2xl font-semibold">
              {userSettings.first_name?.[0]}{userSettings.last_name?.[0]}
            </div>
            <button className="px-4 py-2 bg-slate-700 text-white rounded-lg hover:bg-slate-600 transition-colors flex items-center gap-2">
              <Upload className="w-4 h-4" />
              Upload Photo
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">First Name</label>
              <input
                type="text"
                value={userSettings.first_name}
                onChange={(e) => setUserSettings({ ...userSettings, first_name: e.target.value })}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Last Name</label>
              <input
                type="text"
                value={userSettings.last_name}
                onChange={(e) => setUserSettings({ ...userSettings, last_name: e.target.value })}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Email</label>
              <input
                type="email"
                value={userSettings.email}
                onChange={(e) => setUserSettings({ ...userSettings, email: e.target.value })}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Phone</label>
              <input
                type="tel"
                value={userSettings.phone}
                onChange={(e) => setUserSettings({ ...userSettings, phone: e.target.value })}
                className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
          <div className="mt-6 flex justify-end">
            <button
              onClick={handleSave}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              Save Changes
            </button>
          </div>
        </div>
      )}

      {/* Security Settings */}
      {activeTab === 'security' && (
        <div className="space-y-6">
          <div className="bg-slate-800 rounded-xl border border-slate-700 p-6">
            <h2 className="text-lg font-semibold text-white mb-6">Change Password</h2>
            <div className="space-y-4 max-w-md">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Current Password</label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={userSettings.current_password}
                    onChange={(e) => setUserSettings({ ...userSettings, current_password: e.target.value })}
                    className="w-full px-3 py-2 pr-10 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">New Password</label>
                <input
                  type="password"
                  value={userSettings.new_password}
                  onChange={(e) => setUserSettings({ ...userSettings, new_password: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Confirm New Password</label>
                <input
                  type="password"
                  value={userSettings.confirm_password}
                  onChange={(e) => setUserSettings({ ...userSettings, confirm_password: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors">
                Update Password
              </button>
            </div>
          </div>

          <div className="bg-slate-800 rounded-xl border border-slate-700 p-6">
            <h2 className="text-lg font-semibold text-white mb-4">Two-Factor Authentication</h2>
            <p className="text-slate-400 mb-4">Add an extra layer of security to your account</p>
            <button className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-500 transition-colors">
              Enable 2FA
            </button>
          </div>
        </div>
      )}

      {/* Notifications Settings */}
      {activeTab === 'notifications' && (
        <div className="bg-slate-800 rounded-xl border border-slate-700 p-6">
          <h2 className="text-lg font-semibold text-white mb-6">Notification Preferences</h2>
          <div className="space-y-6">
            <div>
              <h3 className="font-medium text-white mb-4">Email Notifications</h3>
              <div className="space-y-3">
                {[
                  { key: 'email_deals', label: 'New deals and updates' },
                  { key: 'email_documents', label: 'Document signing requests' },
                  { key: 'email_payments', label: 'Payment notifications' },
                  { key: 'email_reports', label: 'Weekly reports' },
                ].map((item) => (
                  <label key={item.key} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg cursor-pointer">
                    <span className="text-slate-300">{item.label}</span>
                    <input
                      type="checkbox"
                      checked={notifications[item.key as keyof typeof notifications]}
                      onChange={(e) => setNotifications({ ...notifications, [item.key]: e.target.checked })}
                      className="w-5 h-5 rounded bg-slate-600 border-slate-500 text-blue-600 focus:ring-blue-500 focus:ring-offset-slate-800"
                    />
                  </label>
                ))}
              </div>
            </div>
            <div>
              <h3 className="font-medium text-white mb-4">Push Notifications</h3>
              <div className="space-y-3">
                {[
                  { key: 'push_deals', label: 'Deal status changes' },
                  { key: 'push_documents', label: 'Document updates' },
                ].map((item) => (
                  <label key={item.key} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg cursor-pointer">
                    <span className="text-slate-300">{item.label}</span>
                    <input
                      type="checkbox"
                      checked={notifications[item.key as keyof typeof notifications]}
                      onChange={(e) => setNotifications({ ...notifications, [item.key]: e.target.checked })}
                      className="w-5 h-5 rounded bg-slate-600 border-slate-500 text-blue-600 focus:ring-blue-500 focus:ring-offset-slate-800"
                    />
                  </label>
                ))}
              </div>
            </div>
          </div>
          <div className="mt-6 flex justify-end">
            <button
              onClick={handleSave}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              Save Preferences
            </button>
          </div>
        </div>
      )}

      {/* Branding Settings */}
      {activeTab === 'branding' && (
        <div className="bg-slate-800 rounded-xl border border-slate-700 p-6">
          <h2 className="text-lg font-semibold text-white mb-6">Branding & Customization</h2>
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Logo</label>
              <div className="flex items-center gap-4">
                <div className="w-24 h-24 bg-slate-700 rounded-lg flex items-center justify-center">
                  <Building2 className="w-10 h-10 text-slate-500" />
                </div>
                <button className="px-4 py-2 bg-slate-700 text-white rounded-lg hover:bg-slate-600 transition-colors flex items-center gap-2">
                  <Upload className="w-4 h-4" />
                  Upload Logo
                </button>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Primary Color</label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={dealershipSettings.primary_color}
                    onChange={(e) => setDealershipSettings({ ...dealershipSettings, primary_color: e.target.value })}
                    className="w-12 h-12 rounded-lg cursor-pointer bg-transparent"
                  />
                  <input
                    type="text"
                    value={dealershipSettings.primary_color}
                    onChange={(e) => setDealershipSettings({ ...dealershipSettings, primary_color: e.target.value })}
                    className="flex-1 px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Secondary Color</label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={dealershipSettings.secondary_color}
                    onChange={(e) => setDealershipSettings({ ...dealershipSettings, secondary_color: e.target.value })}
                    className="w-12 h-12 rounded-lg cursor-pointer bg-transparent"
                  />
                  <input
                    type="text"
                    value={dealershipSettings.secondary_color}
                    onChange={(e) => setDealershipSettings({ ...dealershipSettings, secondary_color: e.target.value })}
                    className="flex-1 px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>
            <div className="p-4 bg-slate-700/50 rounded-lg">
              <p className="text-sm text-slate-400 mb-3">Preview</p>
              <div className="flex items-center gap-4">
                <div 
                  className="w-16 h-16 rounded-lg flex items-center justify-center"
                  style={{ backgroundColor: dealershipSettings.primary_color }}
                >
                  <Building2 className="w-8 h-8 text-white" />
                </div>
                <div>
                  <p className="font-semibold text-white">{dealershipSettings.name || 'Your Dealership'}</p>
                  <p 
                    className="text-sm"
                    style={{ color: dealershipSettings.secondary_color }}
                  >
                    Premium Auto Sales
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-6 flex justify-end">
            <button
              onClick={handleSave}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              Save Branding
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default SettingsView;
