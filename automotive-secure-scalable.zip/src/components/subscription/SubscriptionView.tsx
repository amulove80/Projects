import React, { useState } from 'react';
import { useDealership } from '@/contexts/DealershipContext';
import { SubscriptionPlan } from '@/types';
import { 
  CreditCard, 
  Check, 
  X,
  Zap,
  Building2,
  Crown,
  AlertCircle,
  Calendar,
  DollarSign,
  Users,
  Car,
  FileText,
  Shield
} from 'lucide-react';

const SubscriptionView: React.FC = () => {
  const { currentDealership } = useDealership();
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);

  const plans: SubscriptionPlan[] = [
    {
      id: 'starter',
      name: 'Starter',
      price: 99,
      yearlyPrice: 79,
      features: [
        'Up to 25 vehicles',
        '2 user accounts',
        'Basic document generation',
        'Email support',
        'Basic reporting',
      ],
      maxVehicles: 25,
      maxUsers: 2,
      documentsIncluded: true,
      apiAccess: false,
      prioritySupport: false,
    },
    {
      id: 'professional',
      name: 'Professional',
      price: 249,
      yearlyPrice: 199,
      features: [
        'Up to 100 vehicles',
        '10 user accounts',
        'All document types',
        'Priority email support',
        'Advanced reporting',
        'Custom branding',
        'API access',
      ],
      maxVehicles: 100,
      maxUsers: 10,
      documentsIncluded: true,
      apiAccess: true,
      prioritySupport: true,
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      price: 499,
      yearlyPrice: 399,
      features: [
        'Unlimited vehicles',
        'Unlimited users',
        'All document types',
        '24/7 phone support',
        'Custom reporting',
        'White-label branding',
        'Full API access',
        'Dedicated account manager',
        'Custom integrations',
      ],
      maxVehicles: -1,
      maxUsers: -1,
      documentsIncluded: true,
      apiAccess: true,
      prioritySupport: true,
    },
  ];

  const currentPlan = plans.find(p => p.id === currentDealership?.subscription_plan) || plans[0];

  const getPlanIcon = (planId: string) => {
    switch (planId) {
      case 'starter': return Zap;
      case 'professional': return Building2;
      case 'enterprise': return Crown;
      default: return Zap;
    }
  };

  const getPlanColor = (planId: string) => {
    switch (planId) {
      case 'starter': return 'from-slate-500 to-slate-600';
      case 'professional': return 'from-blue-500 to-blue-600';
      case 'enterprise': return 'from-purple-500 to-purple-600';
      default: return 'from-slate-500 to-slate-600';
    }
  };

  const handleUpgrade = (planId: string) => {
    setSelectedPlan(planId);
    setShowUpgradeModal(true);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Subscription Management</h1>
          <p className="text-slate-400">Manage your plan and billing</p>
        </div>
      </div>

      {/* Current Plan Status */}
      <div className="bg-slate-800 rounded-xl border border-slate-700 p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${getPlanColor(currentPlan.id)} flex items-center justify-center`}>
              {React.createElement(getPlanIcon(currentPlan.id), { className: 'w-7 h-7 text-white' })}
            </div>
            <div>
              <h2 className="text-xl font-semibold text-white">{currentPlan.name} Plan</h2>
              <p className="text-slate-400">
                ${billingCycle === 'monthly' ? currentPlan.price : currentPlan.yearlyPrice}/month
                {billingCycle === 'yearly' && <span className="text-emerald-400 ml-2">Save 20%</span>}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${
              currentDealership?.subscription_status === 'active' 
                ? 'bg-emerald-500/20 text-emerald-400' 
                : currentDealership?.subscription_status === 'trial'
                ? 'bg-blue-500/20 text-blue-400'
                : 'bg-amber-500/20 text-amber-400'
            }`}>
              {currentDealership?.subscription_status === 'active' ? 'Active' : 
               currentDealership?.subscription_status === 'trial' ? 'Trial' : 'Inactive'}
            </span>
          </div>
        </div>

        {/* Usage Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
          <div className="bg-slate-700/50 rounded-lg p-4">
            <div className="flex items-center gap-2 text-slate-400 mb-2">
              <Car className="w-4 h-4" />
              <span className="text-sm">Vehicles</span>
            </div>
            <p className="text-2xl font-bold text-white">
              12 / {currentPlan.maxVehicles === -1 ? '∞' : currentPlan.maxVehicles}
            </p>
            <div className="h-1.5 bg-slate-600 rounded-full mt-2 overflow-hidden">
              <div 
                className="h-full bg-blue-500 rounded-full"
                style={{ width: currentPlan.maxVehicles === -1 ? '10%' : `${(12 / currentPlan.maxVehicles) * 100}%` }}
              />
            </div>
          </div>
          <div className="bg-slate-700/50 rounded-lg p-4">
            <div className="flex items-center gap-2 text-slate-400 mb-2">
              <Users className="w-4 h-4" />
              <span className="text-sm">Users</span>
            </div>
            <p className="text-2xl font-bold text-white">
              3 / {currentPlan.maxUsers === -1 ? '∞' : currentPlan.maxUsers}
            </p>
            <div className="h-1.5 bg-slate-600 rounded-full mt-2 overflow-hidden">
              <div 
                className="h-full bg-emerald-500 rounded-full"
                style={{ width: currentPlan.maxUsers === -1 ? '10%' : `${(3 / currentPlan.maxUsers) * 100}%` }}
              />
            </div>
          </div>
          <div className="bg-slate-700/50 rounded-lg p-4">
            <div className="flex items-center gap-2 text-slate-400 mb-2">
              <FileText className="w-4 h-4" />
              <span className="text-sm">Documents Generated</span>
            </div>
            <p className="text-2xl font-bold text-white">47</p>
            <p className="text-sm text-slate-400 mt-1">This month</p>
          </div>
        </div>
      </div>

      {/* Billing Cycle Toggle */}
      <div className="flex items-center justify-center gap-4">
        <span className={`text-sm ${billingCycle === 'monthly' ? 'text-white' : 'text-slate-400'}`}>Monthly</span>
        <button
          onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'yearly' : 'monthly')}
          className={`relative w-14 h-7 rounded-full transition-colors ${
            billingCycle === 'yearly' ? 'bg-blue-600' : 'bg-slate-600'
          }`}
        >
          <span
            className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-transform ${
              billingCycle === 'yearly' ? 'translate-x-8' : 'translate-x-1'
            }`}
          />
        </button>
        <span className={`text-sm ${billingCycle === 'yearly' ? 'text-white' : 'text-slate-400'}`}>
          Yearly <span className="text-emerald-400">(Save 20%)</span>
        </span>
      </div>

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans.map((plan) => {
          const Icon = getPlanIcon(plan.id);
          const isCurrentPlan = plan.id === currentPlan.id;
          const price = billingCycle === 'monthly' ? plan.price : plan.yearlyPrice;
          
          return (
            <div
              key={plan.id}
              className={`bg-slate-800 rounded-xl border ${
                isCurrentPlan ? 'border-blue-500' : 'border-slate-700'
              } p-6 relative ${plan.id === 'professional' ? 'ring-2 ring-blue-500' : ''}`}
            >
              {plan.id === 'professional' && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-blue-600 text-white text-xs font-medium rounded-full">
                  Most Popular
                </div>
              )}
              
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${getPlanColor(plan.id)} flex items-center justify-center mb-4`}>
                <Icon className="w-6 h-6 text-white" />
              </div>
              
              <h3 className="text-xl font-semibold text-white">{plan.name}</h3>
              <div className="mt-2 mb-4">
                <span className="text-3xl font-bold text-white">${price}</span>
                <span className="text-slate-400">/month</span>
                {billingCycle === 'yearly' && (
                  <p className="text-sm text-slate-400 mt-1">Billed annually</p>
                )}
              </div>

              <ul className="space-y-3 mb-6">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-center gap-2 text-sm text-slate-300">
                    <Check className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>

              <button
                onClick={() => handleUpgrade(plan.id)}
                disabled={isCurrentPlan}
                className={`w-full py-2.5 rounded-lg font-medium transition-colors ${
                  isCurrentPlan
                    ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
                    : plan.id === 'professional'
                    ? 'bg-blue-600 text-white hover:bg-blue-500'
                    : 'bg-slate-700 text-white hover:bg-slate-600'
                }`}
              >
                {isCurrentPlan ? 'Current Plan' : 'Upgrade'}
              </button>
            </div>
          );
        })}
      </div>

      {/* Payment Method */}
      <div className="bg-slate-800 rounded-xl border border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <CreditCard className="w-5 h-5" />
          Payment Method
        </h3>
        <div className="flex items-center justify-between p-4 bg-slate-700/50 rounded-lg">
          <div className="flex items-center gap-4">
            <div className="w-12 h-8 bg-gradient-to-r from-blue-600 to-blue-400 rounded flex items-center justify-center">
              <span className="text-white text-xs font-bold">VISA</span>
            </div>
            <div>
              <p className="text-white font-medium">•••• •••• •••• 4242</p>
              <p className="text-sm text-slate-400">Expires 12/2027</p>
            </div>
          </div>
          <button className="text-blue-400 hover:text-blue-300 text-sm font-medium">
            Update
          </button>
        </div>
      </div>

      {/* Billing History */}
      <div className="bg-slate-800 rounded-xl border border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <Calendar className="w-5 h-5" />
          Billing History
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left text-sm text-slate-400 border-b border-slate-700">
                <th className="pb-3">Date</th>
                <th className="pb-3">Description</th>
                <th className="pb-3">Amount</th>
                <th className="pb-3">Status</th>
                <th className="pb-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700">
              {[
                { date: 'Jan 1, 2026', description: 'Professional Plan - Monthly', amount: 249, status: 'Paid' },
                { date: 'Dec 1, 2025', description: 'Professional Plan - Monthly', amount: 249, status: 'Paid' },
                { date: 'Nov 1, 2025', description: 'Professional Plan - Monthly', amount: 249, status: 'Paid' },
              ].map((invoice, index) => (
                <tr key={index} className="text-sm">
                  <td className="py-3 text-slate-300">{invoice.date}</td>
                  <td className="py-3 text-white">{invoice.description}</td>
                  <td className="py-3 text-white">${invoice.amount}</td>
                  <td className="py-3">
                    <span className="px-2 py-1 bg-emerald-500/20 text-emerald-400 rounded text-xs font-medium">
                      {invoice.status}
                    </span>
                  </td>
                  <td className="py-3">
                    <button className="text-blue-400 hover:text-blue-300 text-sm">
                      Download
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Upgrade Modal */}
      {showUpgradeModal && selectedPlan && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setShowUpgradeModal(false)} />
          <div className="relative bg-slate-800 rounded-xl border border-slate-700 w-full max-w-md p-6">
            <h2 className="text-xl font-semibold text-white mb-4">Upgrade to {plans.find(p => p.id === selectedPlan)?.name}</h2>
            <p className="text-slate-400 mb-6">
              You're about to upgrade your subscription. Your new plan will be effective immediately.
            </p>
            <div className="bg-slate-700/50 rounded-lg p-4 mb-6">
              <div className="flex items-center justify-between">
                <span className="text-slate-300">New monthly charge</span>
                <span className="text-xl font-bold text-white">
                  ${billingCycle === 'monthly' 
                    ? plans.find(p => p.id === selectedPlan)?.price 
                    : plans.find(p => p.id === selectedPlan)?.yearlyPrice}
                </span>
              </div>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setShowUpgradeModal(false)}
                className="flex-1 px-4 py-2 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  alert('Upgrade successful! (Demo)');
                  setShowUpgradeModal(false);
                }}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors"
              >
                Confirm Upgrade
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SubscriptionView;
