import React, { useState, useMemo } from 'react';
import { useDealership } from '@/contexts/DealershipContext';
import { Vehicle } from '@/types';
import { 
  Car, 
  Plus, 
  Search, 
  Filter, 
  Grid, 
  List, 
  MoreVertical,
  Edit,
  Trash2,
  Eye,
  X,
  ChevronDown,
  Gauge,
  Calendar,
  DollarSign
} from 'lucide-react';

const InventoryView: React.FC = () => {
  const { vehicles, addVehicle, updateVehicle, deleteVehicle } = useDealership();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [conditionFilter, setConditionFilter] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);
  const [showDropdown, setShowDropdown] = useState<string | null>(null);

  const [newVehicle, setNewVehicle] = useState({
    year: new Date().getFullYear(),
    make: '',
    model: '',
    trim: '',
    vin: '',
    stock_number: '',
    body_type: '',
    exterior_color: '',
    interior_color: '',
    mileage: 0,
    listing_price: 0,
    condition: 'used' as const,
    status: 'available' as const,
    engine: '',
    transmission: '',
    fuel_type: '',
    description: '',
  });

  const filteredVehicles = useMemo(() => {
    return vehicles.filter(vehicle => {
      const matchesSearch = 
        `${vehicle.year} ${vehicle.make} ${vehicle.model} ${vehicle.vin} ${vehicle.stock_number}`
          .toLowerCase()
          .includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === 'all' || vehicle.status === statusFilter;
      const matchesCondition = conditionFilter === 'all' || vehicle.condition === conditionFilter;
      return matchesSearch && matchesStatus && matchesCondition;
    });
  }, [vehicles, searchQuery, statusFilter, conditionFilter]);

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      available: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
      pending: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
      sold: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      reserved: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
    };
    return colors[status] || 'bg-slate-500/20 text-slate-400 border-slate-500/30';
  };

  const getConditionColor = (condition: string) => {
    const colors: Record<string, string> = {
      new: 'bg-emerald-500/20 text-emerald-400',
      certified: 'bg-blue-500/20 text-blue-400',
      used: 'bg-slate-500/20 text-slate-400',
    };
    return colors[condition] || 'bg-slate-500/20 text-slate-400';
  };

  const handleAddVehicle = async () => {
    if (!newVehicle.make || !newVehicle.model) return;
    
    await addVehicle({
      ...newVehicle,
      features: [],
      images: [],
    });
    
    setShowAddModal(false);
    setNewVehicle({
      year: new Date().getFullYear(),
      make: '',
      model: '',
      trim: '',
      vin: '',
      stock_number: '',
      body_type: '',
      exterior_color: '',
      interior_color: '',
      mileage: 0,
      listing_price: 0,
      condition: 'used',
      status: 'available',
      engine: '',
      transmission: '',
      fuel_type: '',
      description: '',
    });
  };

  const handleDeleteVehicle = async (id: string) => {
    if (confirm('Are you sure you want to delete this vehicle?')) {
      await deleteVehicle(id);
      setShowDropdown(null);
    }
  };

  const handleStatusChange = async (id: string, status: string) => {
    await updateVehicle(id, { status: status as Vehicle['status'] });
    setShowDropdown(null);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Inventory Management</h1>
          <p className="text-slate-400">{filteredVehicles.length} vehicles in inventory</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Add Vehicle
        </button>
      </div>

      {/* Filters */}
      <div className="bg-slate-800 rounded-xl border border-slate-700 p-4">
        <div className="flex flex-col md:flex-row gap-4">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search by make, model, VIN, or stock number..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Status Filter */}
          <div className="relative">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="appearance-none px-4 py-2 pr-10 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Status</option>
              <option value="available">Available</option>
              <option value="pending">Pending</option>
              <option value="sold">Sold</option>
              <option value="reserved">Reserved</option>
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
          </div>

          {/* Condition Filter */}
          <div className="relative">
            <select
              value={conditionFilter}
              onChange={(e) => setConditionFilter(e.target.value)}
              className="appearance-none px-4 py-2 pr-10 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Conditions</option>
              <option value="new">New</option>
              <option value="certified">Certified</option>
              <option value="used">Used</option>
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
          </div>

          {/* View Toggle */}
          <div className="flex items-center bg-slate-700 rounded-lg p-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded-md transition-colors ${viewMode === 'grid' ? 'bg-slate-600 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              <Grid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-md transition-colors ${viewMode === 'list' ? 'bg-slate-600 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Vehicle Grid/List */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredVehicles.map((vehicle) => (
            <div
              key={vehicle.id}
              className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden hover:border-slate-600 transition-all group"
            >
              {/* Image */}
              <div className="relative h-48 bg-slate-700">
                <div className="absolute inset-0 flex items-center justify-center">
                  <Car className="w-16 h-16 text-slate-600" />
                </div>
                <div className="absolute top-3 left-3">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${getConditionColor(vehicle.condition)}`}>
                    {vehicle.condition}
                  </span>
                </div>
                <div className="absolute top-3 right-3">
                  <span className={`px-2 py-1 rounded text-xs font-medium border ${getStatusColor(vehicle.status)}`}>
                    {vehicle.status}
                  </span>
                </div>
                {/* Actions */}
                <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="relative">
                    <button
                      onClick={() => setShowDropdown(showDropdown === vehicle.id ? null : vehicle.id)}
                      className="p-2 bg-slate-800/90 rounded-lg text-white hover:bg-slate-700"
                    >
                      <MoreVertical className="w-4 h-4" />
                    </button>
                    {showDropdown === vehicle.id && (
                      <>
                        <div className="fixed inset-0 z-40" onClick={() => setShowDropdown(null)} />
                        <div className="absolute right-0 bottom-full mb-2 w-40 bg-slate-800 border border-slate-700 rounded-lg shadow-xl z-50 py-1">
                          <button
                            onClick={() => {
                              setSelectedVehicle(vehicle);
                              setShowDetailModal(true);
                              setShowDropdown(null);
                            }}
                            className="w-full flex items-center gap-2 px-3 py-2 text-slate-300 hover:bg-slate-700"
                          >
                            <Eye className="w-4 h-4" /> View Details
                          </button>
                          <button className="w-full flex items-center gap-2 px-3 py-2 text-slate-300 hover:bg-slate-700">
                            <Edit className="w-4 h-4" /> Edit
                          </button>
                          <div className="border-t border-slate-700 my-1" />
                          <button
                            onClick={() => handleStatusChange(vehicle.id, 'pending')}
                            className="w-full flex items-center gap-2 px-3 py-2 text-amber-400 hover:bg-slate-700"
                          >
                            Mark Pending
                          </button>
                          <button
                            onClick={() => handleStatusChange(vehicle.id, 'sold')}
                            className="w-full flex items-center gap-2 px-3 py-2 text-emerald-400 hover:bg-slate-700"
                          >
                            Mark Sold
                          </button>
                          <div className="border-t border-slate-700 my-1" />
                          <button
                            onClick={() => handleDeleteVehicle(vehicle.id)}
                            className="w-full flex items-center gap-2 px-3 py-2 text-red-400 hover:bg-slate-700"
                          >
                            <Trash2 className="w-4 h-4" /> Delete
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-4">
                <h3 className="font-semibold text-white text-lg">
                  {vehicle.year} {vehicle.make} {vehicle.model}
                </h3>
                {vehicle.trim && (
                  <p className="text-slate-400 text-sm">{vehicle.trim}</p>
                )}
                <div className="mt-3 flex items-center gap-4 text-sm text-slate-400">
                  <span className="flex items-center gap-1">
                    <Gauge className="w-4 h-4" />
                    {vehicle.mileage.toLocaleString()} mi
                  </span>
                  {vehicle.exterior_color && (
                    <span>{vehicle.exterior_color}</span>
                  )}
                </div>
                <div className="mt-3 flex items-center justify-between">
                  <p className="text-xl font-bold text-white">
                    ${vehicle.listing_price?.toLocaleString()}
                  </p>
                  <p className="text-sm text-slate-500">
                    {vehicle.stock_number}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden">
          <table className="w-full">
            <thead className="bg-slate-700/50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Vehicle</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">VIN</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Stock #</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Mileage</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Price</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Status</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700">
              {filteredVehicles.map((vehicle) => (
                <tr key={vehicle.id} className="hover:bg-slate-700/30 transition-colors">
                  <td className="px-4 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-10 bg-slate-700 rounded flex items-center justify-center">
                        <Car className="w-5 h-5 text-slate-500" />
                      </div>
                      <div>
                        <p className="font-medium text-white">
                          {vehicle.year} {vehicle.make} {vehicle.model}
                        </p>
                        <p className="text-sm text-slate-400">{vehicle.trim}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-4 text-slate-300 font-mono text-sm">{vehicle.vin}</td>
                  <td className="px-4 py-4 text-slate-300">{vehicle.stock_number}</td>
                  <td className="px-4 py-4 text-slate-300">{vehicle.mileage.toLocaleString()} mi</td>
                  <td className="px-4 py-4 text-white font-semibold">${vehicle.listing_price?.toLocaleString()}</td>
                  <td className="px-4 py-4">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${getStatusColor(vehicle.status)}`}>
                      {vehicle.status}
                    </span>
                  </td>
                  <td className="px-4 py-4">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setSelectedVehicle(vehicle);
                          setShowDetailModal(true);
                        }}
                        className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-700 rounded transition-colors"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-700 rounded transition-colors">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteVehicle(vehicle.id)}
                        className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-700 rounded transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Add Vehicle Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setShowAddModal(false)} />
          <div className="relative bg-slate-800 rounded-xl border border-slate-700 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-slate-800 p-5 border-b border-slate-700 flex items-center justify-between">
              <h2 className="text-xl font-semibold text-white">Add New Vehicle</h2>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Year *</label>
                  <input
                    type="number"
                    value={newVehicle.year}
                    onChange={(e) => setNewVehicle({ ...newVehicle, year: parseInt(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Make *</label>
                  <input
                    type="text"
                    value={newVehicle.make}
                    onChange={(e) => setNewVehicle({ ...newVehicle, make: e.target.value })}
                    placeholder="e.g., BMW"
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Model *</label>
                  <input
                    type="text"
                    value={newVehicle.model}
                    onChange={(e) => setNewVehicle({ ...newVehicle, model: e.target.value })}
                    placeholder="e.g., X5"
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Trim</label>
                  <input
                    type="text"
                    value={newVehicle.trim}
                    onChange={(e) => setNewVehicle({ ...newVehicle, trim: e.target.value })}
                    placeholder="e.g., xDrive40i"
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">VIN</label>
                  <input
                    type="text"
                    value={newVehicle.vin}
                    onChange={(e) => setNewVehicle({ ...newVehicle, vin: e.target.value.toUpperCase() })}
                    placeholder="17-character VIN"
                    maxLength={17}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Stock Number</label>
                  <input
                    type="text"
                    value={newVehicle.stock_number}
                    onChange={(e) => setNewVehicle({ ...newVehicle, stock_number: e.target.value })}
                    placeholder="e.g., STK001"
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Mileage</label>
                  <input
                    type="number"
                    value={newVehicle.mileage}
                    onChange={(e) => setNewVehicle({ ...newVehicle, mileage: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Listing Price</label>
                  <input
                    type="number"
                    value={newVehicle.listing_price}
                    onChange={(e) => setNewVehicle({ ...newVehicle, listing_price: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Exterior Color</label>
                  <input
                    type="text"
                    value={newVehicle.exterior_color}
                    onChange={(e) => setNewVehicle({ ...newVehicle, exterior_color: e.target.value })}
                    placeholder="e.g., Alpine White"
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Interior Color</label>
                  <input
                    type="text"
                    value={newVehicle.interior_color}
                    onChange={(e) => setNewVehicle({ ...newVehicle, interior_color: e.target.value })}
                    placeholder="e.g., Black"
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Condition</label>
                  <select
                    value={newVehicle.condition}
                    onChange={(e) => setNewVehicle({ ...newVehicle, condition: e.target.value as 'new' | 'used' | 'certified' })}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="new">New</option>
                    <option value="certified">Certified Pre-Owned</option>
                    <option value="used">Used</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Status</label>
                  <select
                    value={newVehicle.status}
                    onChange={(e) => setNewVehicle({ ...newVehicle, status: e.target.value as 'available' | 'pending' | 'sold' | 'reserved' })}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="available">Available</option>
                    <option value="pending">Pending</option>
                    <option value="reserved">Reserved</option>
                    <option value="sold">Sold</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Description</label>
                <textarea
                  value={newVehicle.description}
                  onChange={(e) => setNewVehicle({ ...newVehicle, description: e.target.value })}
                  rows={3}
                  placeholder="Vehicle description..."
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div className="sticky bottom-0 bg-slate-800 p-5 border-t border-slate-700 flex justify-end gap-3">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleAddVehicle}
                disabled={!newVehicle.make || !newVehicle.model}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Add Vehicle
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Vehicle Detail Modal */}
      {showDetailModal && selectedVehicle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setShowDetailModal(false)} />
          <div className="relative bg-slate-800 rounded-xl border border-slate-700 w-full max-w-3xl max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-slate-800 p-5 border-b border-slate-700 flex items-center justify-between">
              <h2 className="text-xl font-semibold text-white">Vehicle Details</h2>
              <button
                onClick={() => setShowDetailModal(false)}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-5">
              <div className="flex items-start gap-6">
                <div className="w-48 h-36 bg-slate-700 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Car className="w-16 h-16 text-slate-500" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${getConditionColor(selectedVehicle.condition)}`}>
                      {selectedVehicle.condition}
                    </span>
                    <span className={`px-2 py-1 rounded text-xs font-medium border ${getStatusColor(selectedVehicle.status)}`}>
                      {selectedVehicle.status}
                    </span>
                  </div>
                  <h3 className="text-2xl font-bold text-white">
                    {selectedVehicle.year} {selectedVehicle.make} {selectedVehicle.model}
                  </h3>
                  {selectedVehicle.trim && (
                    <p className="text-lg text-slate-400">{selectedVehicle.trim}</p>
                  )}
                  <p className="text-3xl font-bold text-emerald-400 mt-3">
                    ${selectedVehicle.listing_price?.toLocaleString()}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-6">
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <p className="text-sm text-slate-400">VIN</p>
                  <p className="font-mono text-white">{selectedVehicle.vin || 'N/A'}</p>
                </div>
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <p className="text-sm text-slate-400">Stock Number</p>
                  <p className="text-white">{selectedVehicle.stock_number || 'N/A'}</p>
                </div>
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <p className="text-sm text-slate-400">Mileage</p>
                  <p className="text-white">{selectedVehicle.mileage.toLocaleString()} miles</p>
                </div>
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <p className="text-sm text-slate-400">Exterior Color</p>
                  <p className="text-white">{selectedVehicle.exterior_color || 'N/A'}</p>
                </div>
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <p className="text-sm text-slate-400">Interior Color</p>
                  <p className="text-white">{selectedVehicle.interior_color || 'N/A'}</p>
                </div>
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <p className="text-sm text-slate-400">Body Type</p>
                  <p className="text-white">{selectedVehicle.body_type || 'N/A'}</p>
                </div>
              </div>

              {selectedVehicle.description && (
                <div className="mt-6">
                  <h4 className="font-semibold text-white mb-2">Description</h4>
                  <p className="text-slate-300">{selectedVehicle.description}</p>
                </div>
              )}
            </div>
            <div className="sticky bottom-0 bg-slate-800 p-5 border-t border-slate-700 flex justify-end gap-3">
              <button className="px-4 py-2 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg transition-colors">
                Edit Vehicle
              </button>
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors">
                Create Deal
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default InventoryView;
