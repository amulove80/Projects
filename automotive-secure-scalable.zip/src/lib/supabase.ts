import { createClient } from '@supabase/supabase-js';


// Initialize database client
const supabaseUrl = 'https://txhbvehsxjjekujwyqid.databasepad.com';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjY2OTgyZTEyLTFmMTctNDZmNC04ZjAzLTRmMzQ0NjhjOGI3OSJ9.eyJwcm9qZWN0SWQiOiJ0eGhidmVoc3hqamVrdWp3eXFpZCIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzY4MjU2NjQ5LCJleHAiOjIwODM2MTY2NDksImlzcyI6ImZhbW91cy5kYXRhYmFzZXBhZCIsImF1ZCI6ImZhbW91cy5jbGllbnRzIn0.RmcNK_XINM6bGs_mWPBpyF-LYF4Wz67n5qyxswhK62k';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };